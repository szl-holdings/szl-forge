"""Release-container negative tests; production evidence is verified separately."""
import hashlib
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch
import warnings
import zipfile

import verify_release as release


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.payload = b"frozen fixture bytes\n"
        (self.root / "payload.txt").write_bytes(self.payload)
        self.manifest = {"schema": release.SCHEMA,
            "excluded_directories": sorted(release.EXCLUDED_DIRS),
            "excluded_suffixes": sorted(release.EXCLUDED_SUFFIXES),
            "excluded_files": sorted(release.EXCLUDED_FILES), "bindings": {"fixture": True},
            "files": {"payload.txt": {"sha256": release.sha(self.payload), "bytes": len(self.payload)}}}
        self.write_manifest()

    def write_manifest(self):
        (self.root / release.MANIFEST).write_text(json.dumps(self.manifest), encoding="utf-8")

    def check_directory(self):
        # Container tests deliberately replace only the experiment-specific
        # verifier. Actual evidence binding is checked against the real release.
        with patch.object(release, "verify_bindings", return_value={"fixture": True}):
            return release.verify_directory(self.root)

    def make_zip(self, additions=()):
        path = self.root.parent / (self.root.name + ".zip")
        self.addCleanup(path.unlink, missing_ok=True)
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(release.MANIFEST, (self.root / release.MANIFEST).read_bytes())
            archive.writestr("payload.txt", self.payload)
            for name, content in additions:
                archive.writestr(name, content)
        return path

    def test_valid_directory_container(self):
        self.assertEqual(self.check_directory()["status"], "VERIFIED")

    def test_file_change_is_rejected(self):
        (self.root / "payload.txt").write_bytes(b"different bytes")
        with self.assertRaisesRegex(ValueError, "file mismatch"):
            self.check_directory()

    def test_extra_file_is_rejected(self):
        (self.root / "unreviewed.py").write_text("pass")
        with self.assertRaisesRegex(ValueError, "Missing/extra"):
            self.check_directory()

    def test_missing_file_is_rejected(self):
        (self.root / "payload.txt").unlink()
        with self.assertRaisesRegex(ValueError, "Missing/extra"):
            self.check_directory()

    def test_runtime_lock_and_state_do_not_change_sealed_source_set(self):
        (self.root / ".evaluation.lock").write_bytes(b"changing lock state")
        (self.root / "state").mkdir()
        (self.root / "state" / "journal.json").write_text("{}")
        (self.root / "service.log").write_text("mutable runtime output")
        self.assertEqual(self.check_directory()["files"], 1)

    def test_traversal_and_noncanonical_paths_are_rejected(self):
        for name in ("../outside", "/absolute", "C:/outside", "a\\b", "a/../b", "./a", "a//b", "nul\0x"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                release.relative_name(name)

    def test_manifest_cannot_add_exclusions(self):
        self.manifest["excluded_files"].append("unreviewed.py")
        self.write_manifest()
        with self.assertRaisesRegex(ValueError, "exclusions"):
            self.check_directory()

    def test_case_colliding_manifest_names_are_rejected(self):
        self.manifest["files"]["PAYLOAD.txt"] = dict(self.manifest["files"]["payload.txt"])
        with self.assertRaisesRegex(ValueError, "Case-colliding"):
            release.manifest_entries(self.manifest)

    def test_valid_archive_container(self):
        archive = self.make_zip()
        with patch.object(release, "verify_bindings", return_value={"fixture": True}):
            self.assertEqual(release.verify_archive(archive)["members"], 2)

    def test_archive_extra_and_traversal_members_are_rejected(self):
        for name in ("extra.txt", "../escaped.txt"):
            with self.subTest(name=name):
                archive = self.make_zip([(name, b"extra")])
                with self.assertRaises(ValueError):
                    release.verify_archive(archive)

    def test_duplicate_archive_member_is_rejected(self):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            archive = self.make_zip([("payload.txt", b"replacement")])
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            release.verify_archive(archive)

    @staticmethod
    def checkpoint_fixture(nan=False, overlap=False):
        header = {"__metadata__": {"schema": "szl.confirmation.selector/v1", "source_sha256": "a" * 64,
                                   "metadata": "{}"}}
        payload = bytearray()
        for name, shape in release.EXPECTED_SHAPES.items():
            count = 1
            for dimension in shape:
                count *= dimension
            start = len(payload)
            payload.extend(struct.pack("<f", .125) * count)
            header[name] = {"shape": shape, "dtype": "F32", "data_offsets": [start, len(payload)]}
        if nan:
            payload[:4] = struct.pack("<f", float("nan"))
        if overlap:
            item = header["network.0.bias"]
            length = item["data_offsets"][1] - item["data_offsets"][0]
            item["data_offsets"] = [0, length]
        encoded = json.dumps(header).encode()
        return struct.pack("<Q", len(encoded)) + encoded + payload

    def test_checkpoint_plain_bytes_are_verified_without_torch(self):
        metadata, fingerprint, parameters, blocks = release.inspect_checkpoint(self.checkpoint_fixture(), "a" * 64)
        self.assertEqual(metadata, {})
        self.assertEqual(parameters, 26792)
        expected = hashlib.sha256()
        for name, block in sorted(blocks.items()):
            expected.update(name.encode())
            expected.update(block)
        self.assertEqual(expected.hexdigest(), fingerprint)

    def test_nonfinite_or_overlapping_checkpoint_is_rejected(self):
        for options in ({"nan": True}, {"overlap": True}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                release.inspect_checkpoint(self.checkpoint_fixture(**options), "a" * 64)

    def test_checkpoint_policy_source_binding_is_enforced(self):
        with self.assertRaisesRegex(ValueError, "policy source"):
            release.inspect_checkpoint(self.checkpoint_fixture(), "b" * 64)


if __name__ == "__main__":
    unittest.main()
