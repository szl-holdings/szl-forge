"""Read retained release evidence; no training or benchmark episodes are replayed."""
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from server import ConfirmationRuntime

HERE=Path(__file__).resolve().parent

class BenchmarkAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        names=('core.py','policy.py','experiment.py','protocol.json','protocol.sha256','data-receipt.json',
               'training-summary.json','evaluation-attempt.json','evaluation-receipt.json','evaluation.jsonl','benchmark-summary.json')
        for name in names: shutil.copyfile(HERE/name,self.root/name)
        shutil.copytree(HERE/'models',self.root/'models')
        self.runtime=ConfirmationRuntime(self.root)

    def tearDown(self): self.temp.cleanup()

    def test_real_report_is_recomputed_and_cached_by_exact_bytes(self):
        result=self.runtime.benchmark()
        self.assertTrue(result['available'])
        self.assertEqual(result['verification']['rows_verified'],5184)
        self.assertEqual(result['verification']['status'],'SOURCE_BOUND_AND_RECOMPUTED')
        self.assertFalse(result['data']['primary']['overall_pass'])
        self.assertEqual(result,self.runtime.benchmark())

    def test_modified_gates_aggregates_or_intervals_are_rejected_after_cache(self):
        self.runtime.benchmark()
        path=self.root/'benchmark-summary.json'; original=path.read_bytes()
        for field in ('gate','aggregate','interval'):
            with self.subTest(field=field):
                value=json.loads(original)
                if field=='gate': value['primary']['overall_pass']=True
                elif field=='aggregate': value['summaries']['shared_bias']['learned']['accuracy']=1.0
                else: value['primary']['ci95'][0]+=.1
                path.write_text(json.dumps(value),encoding='utf-8')
                with self.assertRaisesRegex(ValueError,'benchmark differs'): self.runtime.benchmark()
                path.write_bytes(original)

    def test_changed_evidence_or_sources_rejected_after_cache(self):
        self.runtime.benchmark()
        for name in ('evaluation.jsonl','evaluation-attempt.json','evaluation-receipt.json','training-summary.json','core.py','models/selector-17.safetensors'):
            with self.subTest(name=name):
                path=self.root/name; original=path.read_bytes()
                path.write_bytes(original+b' ')
                try:
                    # Whitespace in the receipt changes no payload, but its downstream cache key
                    # must refresh and still verify. Semantic weight claims must be rejected.
                    if name=='evaluation-receipt.json':
                        value=json.loads(original); value['weights_unchanged']=False
                        path.write_text(json.dumps(value),encoding='utf-8')
                    with self.assertRaises(ValueError): self.runtime.benchmark()
                finally: path.write_bytes(original)

if __name__=='__main__': unittest.main()
