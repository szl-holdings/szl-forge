"""Loopback-only, source-bound exploratory trials for the confirmation lab."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import re
import sys
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent
FAMILIES = ("clean", "shared_bias", "independent_outliers", "reference_outliers", "bias_drift", "compositional")
POLICIES = ("no_confirmation", "independent_bias", "source_aware", "cheap_only", "reference_only", "random_mixed", "learned")
MODEL_SEEDS = (17, 23, 41)
MAX_BODY = 4096
METRICS = ("accuracy", "paid_cost", "net_utility", "coverage", "confident_wrong", "brier", "log_loss", "probes", "resources_used", "cheap_probes", "reference_probes")
REPORT_LIMITATIONS = [
    "Synthetic finite worlds; supplied prior and likelihoods; only acquisition policy is learned",
    "Six challenge families are public after this run; no further tuning may claim held-out status",
    "Intervals condition on this protocol and average three trained seeds; no general-domain guarantee",
    "Primary learned versus independent-bias comparison changes both inference assumptions and acquisition; strongest-control and source-aware comparisons isolate the practical alternatives",
    "Shared bias assumes source independence for reference; reference-outlier and drift families violate the model",
]


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def timestamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def validate_request(value):
    if not isinstance(value, dict) or set(value) != {"seed", "index", "family", "policy", "model_seed"}:
        raise ValueError("Provide exactly seed, index, family, policy and model_seed")
    for key in ("seed", "index"):
        if type(value[key]) is not int or not 0 <= value[key] <= 2**32 - 1:
            raise ValueError(f"{key} must be an integer from 0 through 4294967295")
    if type(value["model_seed"]) is not int or value["model_seed"] not in MODEL_SEEDS:
        raise ValueError("model_seed must be 17, 23 or 41")
    if type(value["family"]) is not str or value["family"] not in FAMILIES:
        raise ValueError("Unknown family")
    if type(value["policy"]) is not str or value["policy"] not in POLICIES:
        raise ValueError("Unknown policy")
    return dict(value)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def json_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("Duplicate JSON field")
        value[key] = item
    return value


def _same_report(actual, expected, location="summary"):
    if isinstance(expected, dict):
        if not isinstance(actual, dict) or set(actual) != set(expected):
            raise ValueError(f"Unexpected fields at {location}")
        for key, value in expected.items():
            _same_report(actual[key], value, f"{location}.{key}")
    elif isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            raise ValueError(f"Unexpected list at {location}")
        for index, value in enumerate(expected):
            _same_report(actual[index], value, f"{location}[{index}]")
    elif type(expected) in (int, float):
        if type(actual) not in (int, float) or not math.isfinite(actual) or not math.isclose(actual, expected, rel_tol=1e-11, abs_tol=1e-12):
            raise ValueError(f"Recomputed benchmark differs at {location}")
    elif type(actual) is not type(expected) or actual != expected:
        raise ValueError(f"Recomputed benchmark differs at {location}")


def recompute_report(protocol, rows, binding):
    """Independent report calculation; never invokes the experiment's report code."""
    import numpy as np

    if protocol.get("families") != list(FAMILIES) or protocol.get("policies") != list(POLICIES) or protocol.get("model_seeds") != list(MODEL_SEEDS):
        raise ValueError("Unsupported benchmark families, policies or model seeds")
    count = protocol.get("episodes_per_family")
    if type(count) is not int or not 1 <= count <= 10000:
        raise ValueError("Invalid benchmark episode count")
    criterion = protocol.get("primary", {})
    if criterion.get("family") != "shared_bias" or criterion.get("candidate") != "learned" or criterion.get("baseline") != "independent_bias" or criterion.get("metric") != "net_utility":
        raise ValueError("Unsupported primary criterion")
    if criterion.get("required_gain") != .03 or criterion.get("required_ci_low") != 0 or criterion.get("clean_max_utility_regret") != .01:
        raise ValueError("Unsupported benchmark thresholds")
    bootstrap_seed = criterion.get("bootstrap_seed")
    if type(bootstrap_seed) is not int or not 0 <= bootstrap_seed <= 2**32 - 6:
        raise ValueError("Invalid bootstrap seed")
    grouped = {(family, policy): [] for family in FAMILIES for policy in POLICIES}
    values = {(family, policy, index): [] for family in FAMILIES for policy in POLICIES for index in range(count)}
    for row in rows:
        grouped[(row["family"], row["policy"])].append(row)
        values[(row["family"], row["policy"], row["episode_index"])].append(row["net_utility"])
    summaries = {family: {policy: {"rollouts": len(grouped[(family, policy)]),
                   **{metric: float(np.mean([row[metric] for row in grouped[(family, policy)]])) for metric in METRICS}}
                   for policy in POLICIES} for family in FAMILIES}
    table = {family: np.asarray([[np.mean(values[(family, policy, index)]) for policy in POLICIES]
                                 for index in range(count)], dtype=np.float64) for family in FAMILIES}

    def paired(family, candidate, baseline, offset):
        differences = table[family][:, POLICIES.index(candidate)] - table[family][:, POLICIES.index(baseline)]
        rng = np.random.default_rng(bootstrap_seed + offset)
        samples = differences[rng.integers(count, size=(2000, count))].mean(axis=1)
        return {"candidate": candidate, "baseline": baseline, "family": family,
                "mean_gain": float(differences.mean()), "ci95": np.quantile(samples, [.025, .975]).tolist(),
                "episode_clusters": count,
                "method": "Paired bootstrap over episodes; learned seeds averaged within each episode, not independent replicas"}

    primary = paired("shared_bias", "learned", "independent_bias", 0)
    clean = paired("clean", "learned", "independent_bias", 1)
    primary["gain_gate_pass"] = primary["mean_gain"] >= criterion["required_gain"] and primary["ci95"][0] > criterion["required_ci_low"]
    primary["clean_guard_pass"] = clean["mean_gain"] >= -criterion["clean_max_utility_regret"]
    primary["overall_pass"] = primary["gain_gate_pass"] and primary["clean_guard_pass"]
    controls = [name for name in POLICIES if name != "learned"]
    columns = [POLICIES.index(name) for name in [*controls, "learned"]]
    selected = table["shared_bias"][:, columns]
    rng = np.random.default_rng(bootstrap_seed + 5)
    bootstrap = selected[rng.integers(count, size=(2000, count))].mean(axis=1)
    gains = bootstrap[:, -1] - bootstrap[:, :-1].max(axis=1)
    means = selected.mean(axis=0)
    strongest = {"candidate": "learned", "family": "shared_bias", "observed_best_control": controls[int(means[:-1].argmax())],
                 "mean_gain": float(means[-1] - means[:-1].max()), "ci95": np.quantile(gains, [.025, .975]).tolist(),
                 "method": "Paired episode bootstrap; strongest control reselected inside each replicate", "controls": controls}
    return {"schema": "szl.confirmation.results/v1", **binding, "rows": len(rows),
            "primary": primary, "clean_guard": clean, "analytic_comparison": paired("shared_bias", "source_aware", "independent_bias", 2),
            "reference_only_comparisons": {name: paired("shared_bias", name, "reference_only", 3) for name in ("learned", "source_aware")},
            "summaries": summaries, "learned_vs_analytic": paired("shared_bias", "learned", "source_aware", 4),
            "strongest_control_comparison": strongest, "limitations": REPORT_LIMITATIONS}


class ConfirmationRuntime:
    """Admit frozen source and checkpoints before loading executable modules."""

    def __init__(self, root=HERE):
        self.root = Path(root).resolve()
        self.models = {}
        self.experiment = None
        self.policy = None
        self.loaded_sources = None
        self.benchmark_cache = None

    def admitted(self):
        protocol_path = self.root / "protocol.json"
        protocol = read_json(protocol_path)
        protocol_sha = sha(protocol_path)
        if (self.root / "protocol.sha256").read_text(encoding="utf-8").strip() != protocol_sha:
            raise ValueError("Protocol digest mismatch")
        sources = protocol.get("source_sha256", protocol.get("source_hashes"))
        if not isinstance(sources, dict):
            raise ValueError("Protocol must bind source_sha256 or source_hashes")
        observed = {}
        for name in ("core.py", "policy.py", "experiment.py"):
            expected = sources.get(name)
            if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
                raise ValueError(f"Missing frozen digest for {name}")
            observed[name] = sha(self.root / name)
            if observed[name] != expected:
                raise ValueError(f"Frozen source mismatch: {name}")
        if self.loaded_sources is not None and self.loaded_sources != observed:
            raise ValueError("Loaded source changed; restart the service")
        training_path = self.root / "training-summary.json"
        training = read_json(training_path)
        if training.get("schema") != "szl.confirmation.training/v1" or training.get("protocol_sha256") != protocol_sha:
            raise ValueError("Training protocol or schema mismatch")
        data_sha = sha(self.root / "data-receipt.json")
        records = training.get("checkpoints")
        if not isinstance(records, list) or len(records) != 3:
            raise ValueError("Expected three trained checkpoints")
        checkpoints = {}
        for record in records:
            seed = record.get("seed")
            if type(seed) is not int or seed not in MODEL_SEEDS or seed in checkpoints:
                raise ValueError("Invalid checkpoint seed")
            relative = record.get("path")
            expected = record.get("sha256")
            if not isinstance(relative, str) or not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
                raise ValueError("Invalid checkpoint record")
            path = (self.root / relative).resolve()
            if not path.is_relative_to(self.root) or path == self.root:
                raise ValueError("Checkpoint path escapes lab directory")
            if sha(path) != expected:
                raise ValueError("Checkpoint digest mismatch")
            if record.get("protocol_sha256") != protocol_sha or record.get("data_receipt_sha256") != data_sha:
                raise ValueError("Checkpoint provenance mismatch")
            fingerprint = record.get("trained_fingerprint")
            if not isinstance(fingerprint, str) or not re.fullmatch(r"[0-9a-f]{64}", fingerprint):
                raise ValueError("Missing trained fingerprint")
            checkpoints[seed] = {"path": path, "sha256": expected, "trained_fingerprint": fingerprint}
        return {"protocol_sha256": protocol_sha, "training_summary_sha256": sha(training_path),
                "data_receipt_sha256": data_sha,
                "source_sha256": observed, "checkpoints": checkpoints}

    def status(self):
        try:
            admitted = self.admitted()
            return {"ready": True, "state": "READY", "source_sha256": admitted["source_sha256"],
                    "protocol_sha256": admitted["protocol_sha256"],
                    "checkpoints_verified": len(admitted["checkpoints"]),
                    "models_loaded": sorted(self.models), "error": None}
        except (OSError, ValueError, TypeError, KeyError) as exc:
            return {"ready": False, "state": "UNAVAILABLE", "checkpoints_verified": 0,
                    "models_loaded": sorted(self.models), "error": f"{type(exc).__name__}: {exc}"}

    def _load_modules(self, admitted):
        if self.experiment is not None:
            return
        root = str(self.root)
        if root not in sys.path:
            sys.path.insert(0, root)
        for name in ("core", "policy", "experiment"):
            existing = sys.modules.get(name)
            if existing is not None and Path(existing.__file__).resolve() != self.root / f"{name}.py":
                raise ValueError(f"A different {name} module is already loaded")
        self.policy = importlib.import_module("policy")
        self.experiment = importlib.import_module("experiment")
        self.loaded_sources = admitted["source_sha256"]

    def benchmark(self):
        admitted = self.admitted()
        names = ("protocol.json", "training-summary.json", "evaluation-attempt.json", "evaluation-receipt.json", "evaluation.jsonl", "benchmark-summary.json")
        hashes = {name: sha(self.root / name) for name in names}
        key = digest({"artifacts": hashes, "sources": admitted["source_sha256"], "data_receipt": admitted["data_receipt_sha256"]})
        if self.benchmark_cache is not None and self.benchmark_cache[0] == key:
            return self.benchmark_cache[1]
        protocol = read_json(self.root / "protocol.json")
        training = read_json(self.root / "training-summary.json")
        attempt = read_json(self.root / "evaluation-attempt.json")
        receipt = read_json(self.root / "evaluation-receipt.json")
        summary = read_json(self.root / "benchmark-summary.json")
        protocol_sha, training_sha = hashes["protocol.json"], hashes["training-summary.json"]
        expected_attempt = {"protocol_sha256": protocol_sha, "training_summary_sha256": training_sha,
            "checkpoints": {str(row["seed"]): {"path": row["path"], "sha256": row["sha256"], "fingerprint": row["trained_fingerprint"]} for row in training["checkpoints"]}}
        _same_report(attempt, expected_attempt, "evaluation attempt")
        for field, name in (("protocol_sha256", "protocol.json"), ("training_summary_sha256", "training-summary.json"),
                            ("attempt_sha256", "evaluation-attempt.json"), ("evaluation_sha256", "evaluation.jsonl")):
            if receipt.get(field) != hashes[name]:
                raise ValueError(f"Completed evaluation binding mismatch: {field}")
        expected_fingerprints = {str(row["seed"]): row["trained_fingerprint"] for row in training["checkpoints"]}
        if receipt.get("weights_unchanged") is not True or receipt.get("post_evaluation_fingerprints") != expected_fingerprints:
            raise ValueError("Completed evaluation weight verification mismatch")
        raw = (self.root / "evaluation.jsonl").read_bytes()
        if not raw or not raw.endswith(b"\n"):
            raise ValueError("Evaluation journal is empty or incomplete")
        rows = [json.loads(line) for line in raw.splitlines()]
        expected = [(family, index, policy, seed) for family in protocol["families"]
                    for index in range(protocol["episodes_per_family"]) for policy in protocol["policies"]
                    for seed in (protocol["model_seeds"] if policy == "learned" else [None])]
        if len(rows) != len(expected) or receipt.get("rows") != len(rows):
            raise ValueError("Completed evaluation row count mismatch")
        if type(receipt.get("resumed_rows")) is not int or type(receipt.get("new_rows")) is not int or receipt["resumed_rows"] < 0 or receipt["new_rows"] < 0 or receipt["resumed_rows"] + receipt["new_rows"] != len(rows):
            raise ValueError("Completed evaluation progress mismatch")
        for row, identity in zip(rows, expected):
            observed = (row.get("family"), row.get("episode_index"), row.get("policy"), row.get("model_seed"))
            if observed != identity or row.get("seed") != protocol["test_seed"] or row.get("protocol_sha256") != protocol_sha:
                raise ValueError("Evaluation identity or protocol mismatch")
            payload = {key: value for key, value in row.items() if key != "row_sha256"}
            if row.get("row_sha256") != digest(payload):
                raise ValueError("Evaluation row digest mismatch")
            for metric in METRICS:
                if type(row.get(metric)) not in (int, float) or not math.isfinite(row[metric]):
                    raise ValueError("Evaluation contains invalid metrics")
        binding = {"protocol_sha256": protocol_sha, "evaluation_sha256": hashes["evaluation.jsonl"], "training_summary_sha256": training_sha}
        expected_summary = recompute_report(protocol, rows, binding)
        _same_report(summary, expected_summary)
        if hashes != {name: sha(self.root / name) for name in names} or admitted != self.admitted():
            raise ValueError("Benchmark artifacts changed during verification")
        result = {"available": True, "sha256": hashes["benchmark-summary.json"], "data": summary,
                  "verification": {"status": "SOURCE_BOUND_AND_RECOMPUTED", "evaluation_receipt_sha256": hashes["evaluation-receipt.json"],
                                   "rows_verified": len(rows), "scope": "Local integrity and independent aggregation; not a digital signature"}}
        self.benchmark_cache = (key, result)
        return result

    def run(self, request):
        request = validate_request(request)
        before = self.admitted()
        self._load_modules(before)
        selected = None
        checkpoint_sha = None
        fingerprint = None
        if request["policy"] == "learned":
            seed = request["model_seed"]
            record = before["checkpoints"][seed]
            checkpoint_sha = record["sha256"]
            if seed not in self.models:
                model, metadata = self.policy.load(record["path"], checkpoint_sha)
                if metadata.get("protocol_sha256") != before["protocol_sha256"] or metadata.get("data_receipt_sha256") != before["data_receipt_sha256"] or metadata.get("seed") != seed:
                    raise ValueError("Loaded checkpoint metadata mismatch")
                if self.policy.fingerprint(model) != record["trained_fingerprint"]:
                    raise ValueError("Loaded checkpoint fingerprint mismatch")
                self.models[seed] = model
            selected = self.models[seed]
            fingerprint = self.policy.fingerprint(selected)
            if fingerprint != record["trained_fingerprint"]:
                raise ValueError("Cached model differs from the admitted checkpoint")
        result = self.experiment.run_episode(request["seed"], request["index"], request["family"],
                    request["policy"], model=selected, include_history=True)
        after = self.admitted()
        if before != after:
            raise ValueError("Source or checkpoint binding changed during trial")
        if selected is not None and self.policy.fingerprint(selected) != fingerprint:
            raise ValueError("Model weights changed during inference")
        canonical(result)
        binding = {key: before[key] for key in ("protocol_sha256", "training_summary_sha256", "data_receipt_sha256", "source_sha256")}
        binding["checkpoint_sha256"] = checkpoint_sha
        binding["model_fingerprint"] = fingerprint
        return result, binding


class ReceiptStore:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def save(self, payload):
        receipt = {**payload, "receipt_sha256": digest(payload)}
        target = self.directory / (receipt["id"] + ".json")
        temporary = target.with_suffix(".tmp")
        with temporary.open("xb") as stream:
            stream.write(canonical(receipt))
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(target)
        return receipt

    def get(self, ident):
        if not re.fullmatch(r"[0-9a-f]{32}", ident):
            raise KeyError("Unknown trial")
        receipt = read_json(self.directory / (ident + ".json"))
        payload = {key: value for key, value in receipt.items() if key != "receipt_sha256"}
        if receipt.get("id") != ident or receipt.get("receipt_sha256") != digest(payload):
            raise ValueError("Stored receipt integrity check failed")
        return receipt

    def recent(self):
        rows = []
        for path in sorted(self.directory.glob("*.json"), key=lambda p: p.stat().st_mtime_ns, reverse=True)[:12]:
            try:
                row = self.get(path.stem)
                rows.append({key: row[key] for key in ("id", "created_at", "status", "request", "receipt_sha256")})
            except (OSError, ValueError, KeyError, TypeError):
                rows.append({"id": path.stem, "status": "INVALID_RECEIPT"})
        return rows


class ConfirmationServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address=("127.0.0.1", 8766), root=HERE, runtime=None, state_directory=None):
        if address[0] != "127.0.0.1":
            raise ValueError("Only 127.0.0.1 binding is supported")
        self.root = Path(root).resolve()
        self.runtime = runtime if runtime is not None else ConfirmationRuntime(self.root)
        self.receipts = ReceiptStore(state_directory or self.root / "state" / "trials")
        self.trial_lock = threading.Lock()
        super().__init__(address, Handler)


class Handler(BaseHTTPRequestHandler):
    server_version = "SZLConfirmation/0.4"

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def reply(self, code, value, content_type="application/json; charset=utf-8"):
        body = value if isinstance(value, bytes) else canonical(value)
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def admitted(self):
        host = f"127.0.0.1:{self.server.server_port}"
        if self.headers.get_all("Host", []) != [host]:
            self.reply(403, {"error": "Use the loopback address shown by the launcher"})
            return False
        origins = self.headers.get_all("Origin", [])
        if origins and origins != ["http://" + host]:
            self.reply(403, {"error": "Cross-origin access is not admitted"})
            return False
        return True

    def do_GET(self):
        if not self.admitted():
            return
        route = urlsplit(self.path)
        if route.query or route.fragment:
            return self.reply(400, {"error": "Query parameters are not supported"})
        path = route.path
        try:
            if path == "/healthz":
                return self.reply(200, {"service": "szl-foundation-confirmation", "version": "0.4", "status": "UP", "process_id": os.getpid()})
            if path == "/api/status":
                return self.reply(200, {**self.server.runtime.status(), "busy": self.server.trial_lock.locked(),
                       "scope": "Local synthetic research simulator; exploratory trials are not held-out benchmarks",
                       "families": FAMILIES, "policies": POLICIES, "model_seeds": MODEL_SEEDS,
                       "recent_trials": self.server.receipts.recent()})
            if path == "/api/results":
                target = self.server.root / "benchmark-summary.json"
                if not target.exists():
                    return self.reply(200, {"available": False, "message": "No completed benchmark summary is available"})
                return self.reply(200, self.server.runtime.benchmark())
            if path.startswith("/api/trials/"):
                return self.reply(200, self.server.receipts.get(path.removeprefix("/api/trials/")))
            files = {"/": ("index.html", "text/html; charset=utf-8"),
                     "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                     "/style.css": ("style.css", "text/css; charset=utf-8")}
            if path in files:
                filename, mime = files[path]
                return self.reply(200, (self.server.root / "web" / filename).read_bytes(), mime)
            return self.reply(404, {"error": "Unknown route"})
        except (FileNotFoundError, KeyError):
            return self.reply(404, {"error": "Not found"})
        except (OSError, ValueError, TypeError) as exc:
            return self.reply(503, {"error": f"{type(exc).__name__}: {exc}"})

    def do_POST(self):
        if not self.admitted():
            return
        if self.path != "/api/trial":
            return self.reply(404, {"error": "Unknown route"})
        lengths = self.headers.get_all("Content-Length", [])
        if self.headers.get("Transfer-Encoding") is not None or len(lengths) != 1:
            return self.reply(400, {"error": "One Content-Length is required; streaming bodies are unsupported"})
        try:
            if not re.fullmatch(r"[0-9]+", lengths[0]):
                raise ValueError("Invalid Content-Length")
            length = int(lengths[0])
        except ValueError:
            return self.reply(400, {"error": "Invalid Content-Length"})
        if not 0 < length <= MAX_BODY:
            return self.reply(413, {"error": "Request must be between 1 and 4096 bytes"})
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            return self.reply(415, {"error": "Use application/json"})
        try:
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise ValueError("Incomplete request body")
            request = validate_request(json.loads(raw.decode("utf-8"), object_pairs_hook=json_object))
        except (ValueError, UnicodeError):
            return self.reply(400, {"error": "Invalid trial request or JSON fields"})
        if not self.server.trial_lock.acquire(blocking=False):
            return self.reply(429, {"error": "One trial is already running"})
        try:
            status = self.server.runtime.status()
            if not status.get("ready"):
                return self.reply(503, {"error": status.get("error", "Frozen source and weights are unavailable")})
            ident = uuid.uuid4().hex
            created = timestamp()
            try:
                result, binding = self.server.runtime.run(request)
            except Exception as exc:
                failed = self.server.receipts.save({"id": ident, "created_at": created, "completed_at": timestamp(),
                    "status": "FAILED", "scope": "exploratory", "request": request,
                    "request_sha256": digest(request), "error": f"{type(exc).__name__}: {exc}"})
                return self.reply(503, failed)
            receipt = self.server.receipts.save({"id": ident, "created_at": created, "completed_at": timestamp(),
                "status": "COMPLETE", "scope": "exploratory", "request": request,
                "request_sha256": digest(request), "binding": binding, "result": result,
                "result_sha256": digest(result)})
            return self.reply(201, receipt)
        except (OSError, ValueError, TypeError) as exc:
            return self.reply(503, {"error": f"Receipt could not be committed: {type(exc).__name__}: {exc}"})
        finally:
            self.server.trial_lock.release()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=18766)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("port must be between 1 and 65535")
    with ConfirmationServer(("127.0.0.1", args.port)) as server:
        print(json.dumps({"service": "szl-foundation-confirmation", "url": f"http://127.0.0.1:{args.port}",
                          "status": server.runtime.status()}), flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
