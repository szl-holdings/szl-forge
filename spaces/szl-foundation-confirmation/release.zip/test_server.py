"""HTTP and source-admission tests; runtime fixtures do not claim model performance."""
import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest

from server import ConfirmationRuntime, ConfirmationServer, ReceiptStore, canonical, digest, sha, validate_request


REQUEST = {"seed": 140024, "index": 3, "family": "shared_bias", "policy": "source_aware", "model_seed": 17}


class FixtureRuntime:
    def __init__(self):
        self.ready = True
        self.fail = False
        self.calls = []

    def status(self):
        return {"ready": self.ready, "checkpoints_verified": 3 if self.ready else 0,
                "models_loaded": [], "error": None if self.ready else "Fixture unavailable"}

    def run(self, request):
        self.calls.append(request)
        if self.fail:
            raise ValueError("Deliberate fixture failure")
        return {"accuracy": .75, "net_utility": .7, "history": [{"source": "reference", "charged": True}]}, {"fixture": True}

    def benchmark(self):
        raise ValueError('Unbound fixture summary cannot be admitted')


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / "web").mkdir()
        (self.root / "web" / "index.html").write_text("<!doctype html><title>Fixture</title>")
        self.runtime = FixtureRuntime()
        self.server = ConfirmationServer(("127.0.0.1", 0), self.root, self.runtime)
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={"poll_interval": .01}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.temp.cleanup()

    def request(self, method="GET", path="/api/status", body=None, headers=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=3)
        try:
            conn.request(method, path, body=body, headers=headers or {})
            response = conn.getresponse()
            data = response.read()
            return response.status, dict(response.getheaders()), json.loads(data) if response.getheader("Content-Type", "").startswith("application/json") else data
        finally:
            conn.close()

    def post(self, value=None, headers=None):
        return self.request("POST", "/api/trial", canonical(value or REQUEST), headers or {"Content-Type": "application/json"})

    def test_health_is_process_liveness_and_status_is_readiness(self):
        self.runtime.ready = False
        code, _, health = self.request(path="/healthz")
        self.assertEqual(code, 200)
        self.assertEqual(health["status"], "UP")
        self.assertGreater(health["process_id"], 0)
        self.assertFalse(self.request()[2]["ready"])
        self.assertEqual(self.post()[0], 503)
        self.assertFalse(self.runtime.calls)

    def test_wrong_host_and_origin_rejected(self):
        self.assertEqual(self.request(headers={"Host": "attacker.example"})[0], 403)
        self.assertEqual(self.request(headers={"Origin": "https://attacker.example"})[0], 403)
        self.assertEqual(self.post(headers={"Content-Type": "application/json", "Origin": "null"})[0], 403)
        self.assertFalse(self.runtime.calls)

    def test_same_origin_post_allowed(self):
        code, _, receipt = self.post(headers={"Content-Type": "application/json", "Origin": f"http://127.0.0.1:{self.server.server_port}"})
        self.assertEqual(code, 201)
        self.assertEqual(receipt["status"], "COMPLETE")

    def test_duplicate_host_and_content_length_rejected(self):
        for duplicate in ("Host", "Content-Length"):
            with self.subTest(header=duplicate):
                conn = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=3)
                conn.putrequest("POST", "/api/trial", skip_host=True)
                host = f"127.0.0.1:{self.server.server_port}"
                conn.putheader("Host", host)
                conn.putheader("Content-Length", "1")
                conn.putheader(duplicate, host if duplicate == "Host" else "1")
                conn.putheader("Content-Type", "application/json")
                conn.endheaders(b"0")
                response = conn.getresponse()
                self.assertEqual(response.status, 403 if duplicate == "Host" else 400)
                response.read(); conn.close()

    def test_oversize_and_wrong_content_type_rejected(self):
        self.assertEqual(self.request("POST", "/api/trial", b"x" * 4097, {"Content-Type": "application/json"})[0], 413)
        self.assertEqual(self.post(headers={"Content-Type": "text/plain"})[0], 415)
        self.assertFalse(self.runtime.calls)

    def test_duplicate_json_and_wrong_types_rejected(self):
        self.assertEqual(self.request("POST", "/api/trial", b'{"seed":1,"seed":2}', {"Content-Type": "application/json"})[0], 400)
        for patch in ({"seed": True}, {"index": 1.5}, {"model_seed": "17"}, {"family": "missing"}, {"policy": "remote"}, {"extra": 1}):
            with self.subTest(patch=patch):
                self.assertEqual(self.post({**REQUEST, **patch})[0], 400)
        self.assertFalse(self.runtime.calls)

    def test_busy_rejected_without_starting_trial(self):
        with self.server.trial_lock:
            self.assertEqual(self.post()[0], 429)
        self.assertFalse(self.runtime.calls)

    def test_receipt_hash_persistence_and_readback(self):
        code, _, receipt = self.post()
        self.assertEqual(code, 201)
        self.assertEqual(receipt["request_sha256"], digest(REQUEST))
        self.assertEqual(receipt["result_sha256"], digest(receipt["result"]))
        self.assertEqual(receipt["receipt_sha256"], digest({k: v for k, v in receipt.items() if k != "receipt_sha256"}))
        fresh_store = ReceiptStore(self.root / "state" / "trials")
        self.assertEqual(fresh_store.get(receipt["id"]), receipt)
        self.assertEqual(self.request(path="/api/trials/" + receipt["id"])[2], receipt)
        self.assertEqual(self.request()[2]["recent_trials"][0]["id"], receipt["id"])

    def test_tampered_receipt_fails_closed(self):
        receipt = self.post()[2]
        target = self.root / "state" / "trials" / (receipt["id"] + ".json")
        changed = json.loads(target.read_text())
        changed["result"]["accuracy"] = 1
        target.write_bytes(canonical(changed))
        self.assertEqual(self.request(path="/api/trials/" + receipt["id"])[0], 503)
        self.assertEqual(self.request()[2]["recent_trials"][0]["status"], "INVALID_RECEIPT")

    def test_runtime_failure_retained_and_lock_released(self):
        self.runtime.fail = True
        code, _, receipt = self.post()
        self.assertEqual(code, 503)
        self.assertEqual(receipt["status"], "FAILED")
        self.assertIn("Deliberate fixture failure", receipt["error"])
        self.assertEqual(self.server.receipts.get(receipt["id"]), receipt)
        self.assertFalse(self.server.trial_lock.locked())

    def test_static_allowlist_and_security_headers(self):
        code, headers, body = self.request(path="/")
        self.assertEqual(code, 200)
        self.assertIn(b"Fixture", body)
        self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        for path in ("/../server.py", "/state/service.json", "/api/trials/../../server.py", "/?file=server.py"):
            self.assertIn(self.request(path=path)[0], (400, 404))

    def test_optional_benchmark_remains_separate(self):
        self.assertFalse(self.request(path="/api/results")[2]["available"])
        value = {"summaries": {"clean": {"source_aware": {"accuracy": .75}}}, "fixture": True}
        target = self.root / "benchmark-summary.json"
        target.write_bytes(canonical(value))
        code, _, result = self.request(path="/api/results")
        self.assertEqual(code, 503)
        self.assertIn('Unbound fixture summary', result['error'])


class SourceAdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        for name in ("core.py", "policy.py", "experiment.py"):
            (self.root / name).write_text("# test fixture only\n")
        protocol = {"source_sha256": {name: sha(self.root / name) for name in ("core.py", "policy.py", "experiment.py")}}
        (self.root / "protocol.json").write_bytes(canonical(protocol))
        protocol_sha = sha(self.root / "protocol.json")
        (self.root / "protocol.sha256").write_text(protocol_sha + "\n")
        (self.root / "data-receipt.json").write_bytes(canonical({"fixture": True}))
        rows = []
        for seed in (17, 23, 41):
            path = self.root / f"fixture-{seed}.safetensors"
            path.write_bytes(b"fixture, never loaded as weights")
            rows.append({"seed": seed, "path": path.name, "sha256": sha(path), "protocol_sha256": protocol_sha,
                         "data_receipt_sha256": sha(self.root / "data-receipt.json"), "trained_fingerprint": "a" * 64})
        self.training = {"schema": "szl.confirmation.training/v1", "protocol_sha256": protocol_sha, "checkpoints": rows}
        self.write_training()
        self.runtime = ConfirmationRuntime(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def write_training(self):
        (self.root / "training-summary.json").write_bytes(canonical(self.training))

    def test_byte_admission_does_not_claim_models_loaded(self):
        status = self.runtime.status()
        self.assertTrue(status["ready"])
        self.assertEqual(status["checkpoints_verified"], 3)
        self.assertEqual(status["models_loaded"], [])

    def test_changed_source_refused(self):
        (self.root / "core.py").write_text("# altered\n")
        self.assertFalse(self.runtime.status()["ready"])

    def test_changed_protocol_refused(self):
        (self.root / "protocol.json").write_text("{}")
        self.assertIn("Protocol digest mismatch", self.runtime.status()["error"])

    def test_training_protocol_and_checkpoint_tamper_refused(self):
        self.training["protocol_sha256"] = "b" * 64
        self.write_training()
        self.assertFalse(self.runtime.status()["ready"])
        self.training["protocol_sha256"] = sha(self.root / "protocol.json")
        self.write_training()
        (self.root / "fixture-17.safetensors").write_bytes(b"changed")
        self.assertFalse(self.runtime.status()["ready"])

    def test_escaping_checkpoint_path_refused(self):
        self.training["checkpoints"][0]["path"] = "../outside.safetensors"
        self.write_training()
        self.assertIn("escapes", self.runtime.status()["error"])

    def test_existing_module_source_binding_requires_restart(self):
        self.runtime.loaded_sources = {"core.py": "a" * 64}
        self.assertIn("restart", self.runtime.status()["error"])


class ValidationTests(unittest.TestCase):
    def test_exact_integer_bounds(self):
        self.assertEqual(validate_request({**REQUEST, "seed": 2**32 - 1, "index": 0})["index"], 0)
        for patch in ({"seed": -1}, {"seed": 2**32}, {"index": False}, {"model_seed": True}):
            with self.assertRaises(ValueError):
                validate_request({**REQUEST, **patch})

    def test_public_network_binding_rejected(self):
        with self.assertRaises(ValueError):
            ConfirmationServer(("0.0.0.0", 8766))


if __name__ == "__main__":
    unittest.main(verbosity=2)
