"""Verify portable v0.4 release bytes and evidence bindings using the stdlib.

Run: python verify_release.py [--root DIRECTORY] [--archive RELEASE.zip]
Verification does not run training, import torch, or execute packaged source.
Internal hashes establish consistency, not independent authorship signatures.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import struct
import zipfile

MANIFEST = "release-manifest.json"
SCHEMA = "szl.confirmation.release/v1"
EXCLUDED_DIRS = {"__pycache__", ".git", ".pytest_cache", ".mypy_cache", ".ruff_cache",
                 "state", "runtime", ".venv", "venv", "node_modules", ".torch-cache"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".tmp", ".log", ".pid", ".zip"}
EXCLUDED_FILES = {".evaluation.lock"}
EXPECTED_SHAPES = {"network.0.weight": [96, 208], "network.0.bias": [96],
                   "network.2.weight": [64, 96], "network.2.bias": [64],
                   "network.4.weight": [8, 64], "network.4.bias": [8]}
METRICS = ("accuracy", "paid_cost", "net_utility", "coverage", "confident_wrong", "brier",
           "log_loss", "probes", "resources_used", "cheap_probes", "reference_probes")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def relative_name(name):
    require(isinstance(name, str) and name and "\\" not in name and ":" not in name,
            "Invalid relative path")
    require(not any(ord(c) < 32 for c in name), "Control character in path")
    path = PurePosixPath(name)
    require(not path.is_absolute() and str(path) == name and all(p not in (".", "..") for p in path.parts),
            "Absolute, noncanonical or traversal path")
    return name


def excluded(name):
    parts = PurePosixPath(name).parts
    return (name == MANIFEST or name in EXCLUDED_FILES or any(p.lower() in EXCLUDED_DIRS for p in parts[:-1])
            or PurePosixPath(name).suffix.lower() in EXCLUDED_SUFFIXES)


def included_files(root):
    root = Path(root).resolve(strict=True)
    files = {}
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        name = relative_name(path.relative_to(root).as_posix())
        if excluded(name):
            continue
        require(not path.is_symlink() and root in path.resolve(strict=True).parents, "Symlink or escaped file")
        files[name] = path
    require(len({name.casefold() for name in files}) == len(files), "Case-colliding file names")
    return dict(sorted(files.items()))


def decode(data):
    return json.loads(data.decode("utf-8"), parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def manifest_entries(manifest):
    require(manifest.get("schema") == SCHEMA, "Unsupported manifest schema")
    require(manifest.get("excluded_directories") == sorted(EXCLUDED_DIRS), "Unexpected directory exclusions")
    require(manifest.get("excluded_suffixes") == sorted(EXCLUDED_SUFFIXES), "Unexpected suffix exclusions")
    require(manifest.get("excluded_files") == sorted(EXCLUDED_FILES), "Unexpected file exclusions")
    entries = manifest.get("files")
    require(isinstance(entries, dict) and entries, "Empty manifest")
    for name, item in entries.items():
        relative_name(name)
        require(not excluded(name), "Manifest includes an excluded path")
        require(isinstance(item, dict) and set(item) == {"sha256", "bytes"}, "Invalid manifest entry")
        require(re.fullmatch(r"[0-9a-f]{64}", item["sha256"]) is not None, "Invalid manifest digest")
        require(type(item["bytes"]) is int and item["bytes"] >= 0, "Invalid file length")
    require(len({name.casefold() for name in entries}) == len(entries), "Case-colliding manifest entries")
    return entries


def inspect_checkpoint(data, policy_sha):
    require(len(data) >= 8, "Truncated checkpoint")
    header_length = struct.unpack("<Q", data[:8])[0]
    require(2 <= header_length <= 1_000_000 and header_length + 8 <= len(data), "Invalid checkpoint header")
    header = decode(data[8:8+header_length])
    metadata = header.pop("__metadata__", {})
    require(metadata.get("schema") == "szl.confirmation.selector/v1", "Checkpoint schema mismatch")
    require(metadata.get("source_sha256") == policy_sha, "Checkpoint policy source mismatch")
    provenance = json.loads(metadata["metadata"])
    require(set(header) == set(EXPECTED_SHAPES), "Checkpoint tensor set mismatch")
    payload = data[8+header_length:]
    intervals, fingerprint, parameters, blocks = [], hashlib.sha256(), 0, {}
    for name, spec in sorted(header.items()):
        require(spec["dtype"] == "F32" and spec["shape"] == EXPECTED_SHAPES[name], "Checkpoint tensor shape/dtype mismatch")
        start, stop = spec["data_offsets"]
        count = math.prod(spec["shape"])
        require(type(start) is int and type(stop) is int and 0 <= start <= stop <= len(payload)
                and stop-start == count*4, "Invalid tensor offsets")
        block = payload[start:stop]
        require(all(math.isfinite(v[0]) for v in struct.iter_unpack("<f", block)), "Nonfinite checkpoint tensor")
        fingerprint.update(name.encode())
        fingerprint.update(block)
        intervals.append((start, stop))
        parameters += count
        blocks[name] = block
    cursor = 0
    for start, stop in sorted(intervals):
        require(start == cursor, "Overlapping or incomplete tensor payload")
        cursor = stop
    require(cursor == len(payload) and parameters == 26792, "Checkpoint parameter count mismatch")
    return provenance, fingerprint.hexdigest(), parameters, blocks


def verify_checkpoint(data, initial_data, row, protocol_sha, data_sha, policy_sha):
    provenance, fingerprint, parameters, blocks = inspect_checkpoint(data, policy_sha)
    initial_provenance, initial_fingerprint, initial_parameters, initial_blocks = inspect_checkpoint(initial_data, policy_sha)
    require(provenance["protocol_sha256"] == protocol_sha and provenance["data_receipt_sha256"] == data_sha,
            "Checkpoint protocol/data mismatch")
    for name in ("seed", "selected_step", "parameters", "protocol_sha256", "data_receipt_sha256"):
        require(provenance[name] == row[name], f"Checkpoint metadata mismatch: {name}")
    require(initial_provenance == {"seed": row["seed"], "phase": "initial", "protocol_sha256": protocol_sha},
            "Initial checkpoint metadata mismatch")
    require(initial_parameters == parameters == row["parameters"], "Checkpoint parameter count mismatch")
    require(fingerprint == row["trained_fingerprint"] and initial_fingerprint == row["initial_fingerprint"], "Tensor fingerprint mismatch")
    require(row["initial_fingerprint"] != row["trained_fingerprint"] and 0 < row["changed_parameters"] <= parameters,
            "Missing changed-weight evidence")
    changed = sum(a[0] != b[0] for name in blocks
                  for a, b in zip(struct.iter_unpack("<f", blocks[name]), struct.iter_unpack("<f", initial_blocks[name])))
    require(changed == row["changed_parameters"], "Changed parameter count mismatch")


def verify_bindings(read):
    """read(name) returns verified bytes from a directory or directly from ZIP."""
    protocol_data = read("protocol.json")
    protocol_sha = sha(protocol_data)
    require(read("protocol.sha256").decode().strip() == protocol_sha, "Protocol SHA sidecar mismatch")
    protocol = decode(protocol_data)
    require(protocol["schema"] == "szl.confirmation.protocol/v1", "Protocol schema mismatch")
    require(set(protocol["source_sha256"]) == {"core.py", "policy.py", "experiment.py"}, "Protocol source set mismatch")
    for name, digest in protocol["source_sha256"].items():
        require(sha(read(relative_name(name))) == digest, f"Protocol source mismatch: {name}")
    data_receipt_bytes = read("data-receipt.json")
    data_receipt = decode(data_receipt_bytes)
    require(data_receipt["protocol_sha256"] == protocol_sha, "Data protocol mismatch")
    require(set(data_receipt["files"]) == {"data/training.npz", "data/development.npz"}, "Dataset set mismatch")
    for name, digest in data_receipt["files"].items():
        require(sha(read(relative_name(name))) == digest, f"Dataset mismatch: {name}")
    training_bytes = read("training-summary.json")
    training = decode(training_bytes)
    training_sha = sha(training_bytes)
    require(training["schema"] == "szl.confirmation.training/v1" and training["protocol_sha256"] == protocol_sha,
            "Training schema/protocol mismatch")
    checkpoints = training["checkpoints"]
    require([row["seed"] for row in checkpoints] == protocol["model_seeds"], "Training seed set mismatch")
    for row in checkpoints:
        checkpoint = read(relative_name(row["path"]))
        require(sha(checkpoint) == row["sha256"], "Checkpoint byte digest mismatch")
        initial_checkpoint = read(relative_name(row["initial_path"]))
        require(sha(initial_checkpoint) == row["initial_sha256"], "Initial checkpoint byte digest mismatch")
        verify_checkpoint(checkpoint, initial_checkpoint, row, protocol_sha, sha(data_receipt_bytes), sha(read("policy.py")))
    attempt_bytes = read("evaluation-attempt.json")
    attempt = decode(attempt_bytes)
    require(attempt == {"protocol_sha256": protocol_sha, "training_summary_sha256": training_sha,
                       "checkpoints": {str(row["seed"]): {"path": row["path"], "sha256": row["sha256"],
                                                        "fingerprint": row["trained_fingerprint"]} for row in checkpoints}},
            "Evaluation attempt/model binding mismatch")
    evaluation_bytes = read("evaluation.jsonl")
    require(evaluation_bytes.endswith(b"\n"), "Incomplete evaluation row")
    rows = [decode(line) for line in evaluation_bytes.splitlines()]
    expected = [(family, index, policy, seed)
                for family in protocol["families"]
                for index in range(protocol["episodes_per_family"])
                for policy in protocol["policies"]
                for seed in (protocol["model_seeds"] if policy == "learned" else [None])]
    require(len(rows) == len(expected), "Incomplete or extra evaluation rows")
    grouped = {}
    for row, key in zip(rows, expected):
        require((row["family"], row["episode_index"], row["policy"], row["model_seed"]) == key,
                "Evaluation order or identity mismatch")
        require(row["protocol_sha256"] == protocol_sha and row["seed"] == protocol["test_seed"], "Evaluation provenance mismatch")
        content = {k: v for k, v in row.items() if k != "row_sha256"}
        require(sha(json.dumps(content, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()) == row["row_sha256"],
                "Evaluation row digest mismatch")
        history = row["history"]
        require(4 <= len(history) <= 8 and all(r["charged"] is False for r in history[:4])
                and [r["group"] for r in history[:4]] == [0, 1, 2, 3]
                and all(r["source"] == "cheap" for r in history[:4]), "Invalid inherited history")
        require(all(r["charged"] is True for r in history[4:]), "Invalid paid history")
        require(len({r["observation_id"] for r in history}) == len(history), "Duplicate history observation IDs")
        require(row["probes"] == len(history)-4 and row["inherited_observations"] == 4,
                "Observation history accounting mismatch")
        resources = sum(1 if r["source"] == "cheap" else 2 for r in history[4:])
        require(resources == row["resources_used"] <= protocol["budget"], "Resource history mismatch")
        price = math.fsum(protocol["prices"][r["action"]] for r in history[4:])
        require(math.isclose(price, row["paid_cost"], abs_tol=1e-12), "Cost history mismatch")
        require(math.isclose(row["net_utility"], row["accuracy"]-price, abs_tol=1e-12), "Utility accounting mismatch")
        grouped.setdefault((row["family"], row["policy"]), []).append(row)
    evaluation_sha = sha(evaluation_bytes)
    receipt = decode(read("evaluation-receipt.json"))
    summary = decode(read("benchmark-summary.json"))
    for item in (receipt, summary):
        require(item["protocol_sha256"] == protocol_sha and item["training_summary_sha256"] == training_sha
                and item["evaluation_sha256"] == evaluation_sha and item["rows"] == len(rows),
                "Evaluation/summary binding mismatch")
    require(receipt["weights_unchanged"] is True, "Evaluation weight-integrity check failed")
    require(receipt["attempt_sha256"] == sha(attempt_bytes), "Evaluation attempt receipt mismatch")
    require(receipt["post_evaluation_fingerprints"] == {str(row["seed"]): row["trained_fingerprint"] for row in checkpoints},
            "Post-evaluation fingerprint mismatch")
    require(receipt["resumed_rows"] + receipt["new_rows"] == len(rows), "Evaluation resume accounting mismatch")
    require(summary["schema"] == "szl.confirmation.results/v1", "Results schema mismatch")
    for (family, policy), selected in grouped.items():
        aggregate = summary["summaries"][family][policy]
        require(aggregate["rollouts"] == len(selected), "Aggregate rollout count mismatch")
        for metric in METRICS:
            expected_mean = math.fsum(row[metric] for row in selected) / len(selected)
            require(math.isclose(aggregate[metric], expected_mean, abs_tol=1e-10, rel_tol=1e-10),
                    f"Aggregate mismatch: {family}/{policy}/{metric}")
    strongest = summary["strongest_control_comparison"]
    controls = [name for name in protocol["policies"] if name != "learned"]
    require(strongest["controls"] == controls, "Strongest-control set mismatch")
    control_means = {name: summary["summaries"]["shared_bias"][name]["net_utility"] for name in controls}
    best = max(controls, key=control_means.get)
    gain = summary["summaries"]["shared_bias"]["learned"]["net_utility"] - control_means[best]
    require(strongest["observed_best_control"] == best and math.isclose(strongest["mean_gain"], gain, abs_tol=1e-10),
            "Strongest-control observed comparison mismatch")
    return {"protocol_sha256": protocol_sha, "training_summary_sha256": training_sha,
            "evaluation_sha256": evaluation_sha, "evaluation_rows": len(rows),
            "checkpoints": len(checkpoints), "initial_checkpoints": len(checkpoints),
            "tensor_values_verified": 2*sum(row["parameters"] for row in checkpoints)}


def verify_directory(root):
    root = Path(root).resolve(strict=True)
    manifest_bytes = (root / MANIFEST).read_bytes()
    manifest = decode(manifest_bytes)
    entries = manifest_entries(manifest)
    files = included_files(root)
    require(set(files) == set(entries), f"Missing/extra release files: missing={sorted(set(entries)-set(files))}, extra={sorted(set(files)-set(entries))}")
    for name, path in files.items():
        data = path.read_bytes()
        require(len(data) == entries[name]["bytes"] and sha(data) == entries[name]["sha256"], f"Release file mismatch: {name}")
    def read(name):
        require(relative_name(name) in entries, f"Unmanifested evidence path: {name}")
        return files[name].read_bytes()
    bindings = verify_bindings(read)
    require(manifest["bindings"] == bindings, "Manifest evidence bindings mismatch")
    return {"status": "VERIFIED", "kind": "directory", "files": len(entries),
            "manifest_sha256": sha(manifest_bytes), **bindings}


def verify_archive(path):
    path = Path(path).resolve(strict=True)
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "Duplicate ZIP members")
        for name in names:
            relative_name(name)
        manifest_bytes = archive.read(MANIFEST)
        manifest = decode(manifest_bytes)
        entries = manifest_entries(manifest)
        require(set(names) == set(entries) | {MANIFEST}, "Missing/extra ZIP members")
        require(archive.testzip() is None, "ZIP CRC check failed")
        for name, expected in entries.items():
            info = archive.getinfo(name)
            require((info.external_attr >> 16) & 0o170000 != 0o120000, "ZIP contains symlink")
            data = archive.read(name)
            require(len(data) == expected["bytes"] and sha(data) == expected["sha256"], f"ZIP member mismatch: {name}")
        def read(name):
            require(relative_name(name) in entries, f"Unmanifested ZIP evidence: {name}")
            return archive.read(name)
        bindings = verify_bindings(read)
        require(manifest["bindings"] == bindings, "ZIP evidence bindings mismatch")
    return {"status": "VERIFIED", "kind": "archive", "members": len(names),
            "bytes": path.stat().st_size, "sha256": sha(path.read_bytes()),
            "manifest_sha256": sha(manifest_bytes), **bindings}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--archive", type=Path)
    args = parser.parse_args()
    result = verify_archive(args.archive) if args.archive else verify_directory(args.root)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
