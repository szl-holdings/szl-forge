"""Witness local readiness and exact trial persistence around a service restart."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
from urllib.request import Request,urlopen

ROOT=Path(__file__).resolve().parent
BASE='http://127.0.0.1:18766'

def request(path,payload=None):
    body=None if payload is None else json.dumps(payload).encode()
    req=Request(BASE+path,data=body,headers={'Content-Type':'application/json','Origin':BASE})
    with urlopen(req,timeout=45) as response:
        return response.status,json.loads(response.read())

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()

def write(name,value):
    target=ROOT/'evidence'/name
    if target.exists(): raise ValueError('Evidence already exists; preserve the original witness')
    target.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('phase',choices=('before','after')); args=parser.parse_args()
    status_code,health=request('/healthz'); assert status_code==200 and health['status']=='UP'
    _,status=request('/api/status'); assert status['ready'] and status['checkpoints_verified']==3
    _,results=request('/api/results'); assert results['verification']['status']=='SOURCE_BOUND_AND_RECOMPUTED'
    assert results['verification']['rows_verified']==5184 and results['data']['primary']['overall_pass'] is False
    if args.phase=='before':
        receipts=[]
        original_id='4b55b87ec54a4d5a998f3078a90c415d'
        _,original=request('/api/trials/'+original_id)
        expected=json.loads((ROOT/'evidence/browser-trial.json').read_text())
        assert original==expected
        receipts.append({'id':original_id,'sha256':digest(original),'origin':'prior browser trial'})
        for model_seed in (17,23,41):
            code,receipt=request('/api/trial',{'seed':20260925,'index':4,'family':'shared_bias','policy':'learned','model_seed':model_seed})
            assert code==201 and receipt['status']=='COMPLETE'
            assert receipt['result']['inherited_observations']==4 and receipt['result']['resources_used']<=4
            _,readback=request('/api/trials/'+receipt['id']); assert readback==receipt
            receipts.append({'id':receipt['id'],'sha256':digest(receipt),'model_seed':model_seed,
                             'accuracy':receipt['result']['accuracy'],'net_utility':receipt['result']['net_utility']})
        _,status=request('/api/status'); assert status['models_loaded']==[17,23,41]
        write('runtime-before-restart.json',{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'health':health,'status':status,'benchmark_verification':results['verification'],'receipts':receipts})
    else:
        before=json.loads((ROOT/'evidence/runtime-before-restart.json').read_text())
        assert health['process_id']!=before['health']['process_id']
        assert status['models_loaded']==[]
        for row in before['receipts']:
            _,receipt=request('/api/trials/'+row['id']); assert digest(receipt)==row['sha256']
        write('restart-check.json',{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'status':'PASS','before_process_id':before['health']['process_id'],'after_process_id':health['process_id'],
            'saved_receipts_identical':len(before['receipts']),'source_readiness':status['ready'],
            'models_loaded_after_restart':status['models_loaded'],'benchmark_verification':results['verification']})
    print(json.dumps({'phase':args.phase,'status':'PASS','process_id':health['process_id']}))

if __name__=='__main__': main()
