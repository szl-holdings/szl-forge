# Source-aware confirmation: mathematical design and review

Review date: 2026-09-24. This document records a collaborating coding agent's design and implementation review, not external scientific replication or institutional peer review. The sealed v0.3 workbench was read without modification. Its failed utility criterion and poorer performance than stale memory motivated this separate study.

## Research question and limits

Can a learned acquisition policy decide when an independently generated, more expensive reference is worth buying to verify existing reports from a cheaper source whose errors may be correlated? The mechanism is explicit Bayesian inference about source bias plus a trained acquisition controller. It is not learned world-model discovery, a new general intelligence architecture, or a demonstrated scientific first.

The v0.3 noisy mixture treated observation errors independently. Reducing confidence improved some uncertainty metrics but did not repair most corrupted answers. This extension represents a persistent source-level error so that one reference can revise the interpretation of several cheap reports.

## Exact finite belief

There are four true group shifts `X_g` in Z16 and one shared cheap-source bias `B` in Z16. A cheap observation is `Y = X_g + B + E_c (mod 16)`; an independent reference is `Y = X_g + E_r (mod 16)`. Fresh errors are independent conditional on latent world and bias. Independence and source reliability are supplied model assumptions.

The structured world prior contains 76 hypotheses: unchanged, 15 global nonzero shifts, and 60 single-group nonzero shifts. A factorized independent component has support over all 16^4 worlds. The exact compact posterior uses:

- `W[h,b]`: joint posterior mass for a structured hypothesis and bias, shape 76 x 16.
- `Q[b]`: independent-world component mass conditional on a bias, shape 16.
- `U[b,g,x]`: normalized conditional group marginals inside each independent component, shape 16 x 4 x 16.

For an observation of source `s`, group `g`, and label `y`, let `L_s(b,x,y)` be the declared likelihood. Structured masses multiply by `L_s(b,H[h,g],y)`. For each bias, `z_b = sum_x U[b,g,x] L_s(b,x,y)`; multiply `Q[b]` by `z_b` and replace the observed group marginal by `U[b,g,x] L_s(b,x,y)/z_b`. Divide all component masses by one global evidence normalizer. Other group marginals conditional on a component are unchanged. This update is exact because conditioning preserves the within-component factorization.

The world marginal is `P(X_g=x) = sum_h,b W[h,b] 1[H[h,g]=x] + sum_b Q[b] U[b,g,x]`. Cross-group joints use products of conditional group marginals; same-group joints use a diagonal. Treating the same variable as two independent draws would give the wrong action value.

Bias prior probability is 0.8 for zero and 0.2/15 for each nonzero shift. The independent-world mixture weight is 0.2, and each independent group has zero probability 0.8. Structured family priors are equal over unchanged, global, and local. Both assumed fresh-noise rates are 0.02, with errors spread uniformly over the other labels. All values are declared, not fitted to challenge outcomes.

## Acquisition and inherited evidence

Every policy receives four already-acquired cheap reports, one per group, before paid decisions. They consume no new resources and incur no new cost. This is explicitly a verification experiment about existing reports, not a claim that the initial reports were free to collect in practice. The environment and belief reject additional free reports or inherited reports added after paid acquisition starts.

New acquisition has four resource units. A cheap query costs one resource unit and 0.025 accuracy-equivalent utility units. A reference costs two resource units and 0.05 utility units. Repeated paid queries are allowed. Their fresh noise is independently generated conditional on the same source bias; repetition never redraws that latent bias.

For Bayes-optimal final predictions, expected accuracy is `A = sum_g m_g max_x P(X_g=x)`. For candidate action `a` with price `c_a`, exact one-step value is:

`U(a) = sum_y sum_g m_g max_x P(Y_a=y, X_g=x) - A - c_a`.

The predictive joint retains the shared bias. Integrating bias independently at every reading would destroy the cross-report information this mechanism needs. The analytic controller selects the best affordable action only when its value is strictly positive; stopping has zero incremental value. This is a one-step controller, not a globally optimal sequential policy. A pair of observations can sometimes be valuable even when one individually is not, so myopic stopping remains a material limitation.

Optional core features contain each candidate's complete predictive joint, current marginals, goal weights, and action metadata. They are derived from permitted observations and the supplied model. The parent policy instead encodes 208 raw public history features: public goals, family priors, prices, remaining resources, and at most eight observations with source, group, relative label, occupancy, and whether newly purchased. It does not feed exact posterior features to the trained selector.

## Controls, challenge conditions, and fairness

The important controls are no further confirmation, source-aware analytic acquisition, cheap-only acquisition, reference-only acquisition, random affordable mixed-source acquisition, an independent-bias ablation, and the learned selector. Cheap-only and reference-only share the same Bayesian world predictor as source-aware acquisition. The independent-bias ablation preserves the initial per-reading cheap-source likelihood by integrating the same bias prior independently for every observation. It does not substitute a zero-bias likelihood and mislabel that as a correlation ablation.

The six environment families are clean, shared bias, independent cheap-source outliers, reference outliers, bias drift, and compositional two-group changes. Ordinary worlds cycle evenly through unchanged, global, and local shifts. Compositional worlds change two groups. Outlier source rates are 0.25 while the belief retains its 0.02 assumption. Drift switches the cheap source's bias after its first paid cheap query; inherited reports and that first paid query use the initial bias.

Fresh noise is precomputed by action and visit so policies buying the same observation encounter the same noise. Bias drift itself is deliberately dependent on query order, and that exception is explicit. Two-group worlds fall outside the structured prior family but remain inside the full-support independent component. Source-rate changes and bias drift instead violate the assumed measurement model.

A balanced clean/biased primary mixture and comparison with the stronger channel-restricted control were initial review recommendations. The root protocol selected a narrower shared-bias primary comparison against the independent-bias baseline, with a clean-data guard. The reference-only and cheap-only outcomes therefore remain essential secondary controls: primary success alone would not establish superiority over either one. Protocol settings and thresholds must be fixed before observing challenge outcomes. A subsequent hyperparameter search must use a new study and fresh data.

Report all-goal accuracy, paid cost, utility, Brier score, log loss, confidence coverage, confidently wrong mass, actual actions, and resource use together. Reduced confident-error mass is insufficient when coverage falls. The episode is the independent sampling unit; three trained selectors evaluated on the same episode are averaged within that cluster. An unchanged frozen test result remains valid evidence of failure and must not be replaced by an outcome chosen after tuning.

## Mathematical and boundary verification

`test_core.py` passed 20 tests on the native Python CPU runtime in 3.681 seconds. The test oracle independently enumerates all 1,048,576 world/bias states, builds its own priors and likelihoods, and compares compact posterior marginals and all eight one-step action values after mixed inherited/reference observations. It separately checks the independent-bias ablation.

Other tests cover normalization, observation-order invariance, cross-group posterior correction from a reference, repetition versus independent confirmation, identical-likelihood price dominance, nonnegative expected accuracy value before costs, stopping, atomic duplicate rejection, affordability, bounded inherited evidence, action-indexed noise tapes, explicit drift timing, eight-slot histories, feature sufficiency, hidden metadata rejection, and scoring without abstention inflation.

An independent coding agent's separately authored `review_dense.py` also enumerated all 16^5 states, comparing eight posterior states and 1,024 action/response slices across both correlation models. Maximum absolute predictive-joint discrepancy was 8.20e-14; maximum utility discrepancy was 7.74e-14. That reviewer independently reran all 20 core tests successfully in 5.112 seconds and recorded source hashes in `INDEPENDENT_REVIEW.md` and its JSON receipt. These are independent code implementations within the same coding session, not external scientific replication.

The tested core exposes only source, group, observed relative label, and observation ID from the environment. Policy metadata accepts a fixed public schema. Truth is read by the score function after acquisition. Core mathematical correctness does not certify learned-policy quality, application operation, real-world sensor independence, or scientific novelty; those require their own evidence.
