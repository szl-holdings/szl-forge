# Public agency research informing Foundation Confirmation

Read on **24 September 2026**. This review covers four public primary sources from CIA, NSA, IARPA and DARPA. It records useful design precedents rather than ranking agencies or inferring private capabilities. No external code, weights, restricted material, or full publications were imported. Machine-readable findings and source limitations are in [agencies.json](agencies.json).

## What the sources contribute

**CIA: test the evidence that controls the conclusion.** Heuer's discussion of competing hypotheses considers evidence across alternatives and revisits the few observations that strongly influence a judgment. It also describes checking original sources and challenging assumptions. The method remains fallible. [Psychology of Intelligence Analysis, Chapter 8, printed pp. 101–105 and 108–109](https://www.cia.gov/resources/csi/static/Pyschology-of-Intelligence-Analysis.pdf).

**NSA: preserve the origin and integrity of data.** The AISC's May 22, 2025 release highlights provenance, authenticated revisions, data modification and drift. The official press release was read; retrieval of its linked full technical PDF failed, so this review does not attribute additional details to that PDF. [NSA AISC release](https://www.nsa.gov/Press-Room/Press-Releases-Statements/Press-Release-View/Article/4192332/nsas-aisc-releases-joint-guidance-on-the-risks-and-best-practices-in-ai-data-se/).

**IARPA: seek contrary evidence and evaluate the help provided.** REASON's public description targets evidence and reasoning assistance, including alternatives and contradictions, and describes separate evaluation teams. Its solicitation release is dated March 20, 2023. Those are program goals, not evidence that our software meets them. [IARPA REASON](https://www.iarpa.gov/research-programs/reason).

**DARPA: make uncertainty guide experiments.** FoundSci describes skeptical reasoning and hypothesis refinement as scientific-discovery research objectives. Its page is an archived program description marked complete, not a current product claim. [DARPA FoundSci](https://www.darpa.mil/research/programs/foundation-models-for-scientific-discovery).

## Proposed software and mathematical adaptation

Our next experiment should make observation reliability part of the decision, rather than treating every new reading as equally trustworthy. These are our engineering proposals, not methods claimed to be implemented by the agencies above:

1. **Give evidence an identity.** Each observation carries its episode, source/channel, target, acquisition number, cost and observed value. Record what the policy actually saw separately from hidden simulator truth used for scoring.
2. **Represent dependence.** If a channel has a persistent fault for one target, repeated readings may reproduce the same false value. A second copy must not silently become an independent likelihood term. A shared latent fault can express this dependency.
3. **Offer a separate reference action.** Verification should have an explicit price and a stated error model. Include an imperfect-reference condition; independence and correctness are different properties.
4. **Buy information only for a reason.** Compare the expected improvement in the final decision with the acquisition cost. A policy can choose new coverage, repetition, independent verification, or stopping. The simulator must not reveal the fault flag or correct answer to the policy.
5. **Preserve failures.** Compare against naive independent-reading and no-verification baselines on identical episode draws. Freeze success criteria before the held-out run. Report accuracy, cost, utility and confident errors separately, including cases where verification spends money without helping.

The intended falsifiable question is: **When errors persist within a source, can a policy that understands that dependence use a separate reference more effectively than a policy that treats repeated readings as independent?** A positive result in this finite synthetic setting would support that bounded mechanism. It would not establish general scientific discovery, autonomous intelligence analysis, real-world source independence, or AGI.

## Admission and attribution boundaries

The CIA-hosted book contains a notice restricting commercial copying and noting possible copyright restrictions; this folder retains only original summaries and links. Its authors' views are not represented as official CIA endorsement. The other records are public program or press pages, not software repositories: repository revisions and software licenses are therefore not applicable. Any later import of code, data or weights needs its own revision and license review.

Search results from **iarpa.org** were excluded: the official agency source used here is **iarpa.gov**. A hash can establish which bytes were retained; it cannot prove that the observation was true or that two sources were independent. Separate-agent review within this build is internal review, not the institutionally independent evaluation described by IARPA.
