"""Render this fixed release's report/figure; optional matplotlib==3.11.2."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'benchmark-summary.json').read_text())
t=json.loads((ROOT/'training-summary.json').read_text())
p=json.loads((ROOT/'protocol.json').read_text())
names={'no_confirmation':'No extra evidence','independent_bias':'Independent bias','source_aware':'Source-aware analytic',
       'cheap_only':'Paid cheap only','reference_only':'Paid reference only','random_mixed':'Random mixed','learned':'Learned selector'}
order=['no_confirmation','independent_bias','cheap_only','random_mixed','source_aware','reference_only','learned']
shared=s['summaries']['shared_bias']
lines=['# Measured results — Foundation Confirmation v0.4','',
       '**The shared-fault gain passed, but the overall registered gate failed because clean-sensor utility regressed beyond its allowed limit.** The learned model did not establish an advantage over the strongest control.','',
       f"Completed {s['rows']:,} policy rollouts across 576 distinct synthetic worlds: 96 per challenge family, six deterministic/random controls and three separately trained learned selectors. All outcomes below come from this frozen evaluation, not the interactive interface.",'',
       '## Registered result','',
       f"Against the independent-bias system, learned shared-fault utility improved by **{s['primary']['mean_gain']:.6f}** (paired 95% bootstrap interval **[{s['primary']['ci95'][0]:.6f}, {s['primary']['ci95'][1]:.6f}]**). This exceeds the registered 0.03 gain threshold and positive lower confidence bound.",'',
       f"Clean-sensor utility changed by **{s['clean_guard']['mean_gain']:.6f}** (95% interval [{s['clean_guard']['ci95'][0]:.6f}, {s['clean_guard']['ci95'][1]:.6f}]). The allowed mean regression was 0.01. Therefore `overall_pass=false`.",'',
       f"The strongest observed shared-fault control was **paid reference only**. Learned utility minus that control was **{s['strongest_control_comparison']['mean_gain']:.6f}**, interval **[{s['strongest_control_comparison']['ci95'][0]:.6f}, {s['strongest_control_comparison']['ci95'][1]:.6f}]**. The strongest control is reselected inside each bootstrap replicate. Against source-aware analytic acquisition, the learned difference was {s['learned_vs_analytic']['mean_gain']:.6f}, interval [{s['learned_vs_analytic']['ci95'][0]:.6f}, {s['learned_vs_analytic']['ci95'][1]:.6f}]. Neither comparison demonstrates learned superiority.",'',
       '## Shared-fault condition','',
       'Accuracy and confident error are target-weighted proportions. Utility subtracts incremental observation cost; it is not a percentage. Confidence threshold is 0.8. Learned rows average three model seeds on the same 96 worlds.','',
       '| Policy | Accuracy | Utility | Paid cost | Confidently wrong | Mean paid references |',
       '|---|---:|---:|---:|---:|---:|']
for key in order:
    r=shared[key]; lines.append(f"| {names[key]} | {100*r['accuracy']:.2f}% | {r['net_utility']:.6f} | {r['paid_cost']:.6f} | {100*r['confident_wrong']:.2f}% | {r['reference_probes']:.3f} |")
lines+=['','The poor independent-bias result is a targeted model-mismatch result: all four inherited reports can share the same incorrect offset. It does not represent a general comparison with deployed language models. The learned and source-aware systems share a programmed predictor, while the independent-bias system changes both inference and action selection.','',
        '## Every challenge family','',
        '| Condition | Learned accuracy | Learned utility | Analytic utility | Best control utility | Best control |',
        '|---|---:|---:|---:|---:|---|']
for family in p['families']:
    group=s['summaries'][family]; r=group['learned']; best=max((k for k in group if k!='learned'),key=lambda k:group[k]['net_utility'])
    lines.append(f"| {family} | {100*r['accuracy']:.2f}% | {r['net_utility']:.6f} | {group['source_aware']['net_utility']:.6f} | {group[best]['net_utility']:.6f} | {names[best]} |")
lines+=['','These are descriptive secondary comparisons. The learned selector underperforms the independent-bias control on independent cheap outliers and the reference-only control on compositional changes. When references have 25% outlier probability, learned confident error rises to '+f"{100*s['summaries']['reference_outliers']['learned']['confident_wrong']:.2f}%"+'. A separate source is not guaranteed correct.','',
        '## Actual training','',
        'Three 26,792-parameter models trained from fresh weights on CPU using 4,096 synthetic states and 768 development states. Each ran 1,600 optimizer updates; only development decision regret selected checkpoints. The initial and selected SafeTensors, hashes and fingerprints are retained. All 26,792 selected parameters changed for each seed.','',
        '| Seed | Selected step | Initial development regret | Selected development regret |',
        '|---|---:|---:|---:|']
for c in t['checkpoints']: lines.append(f"| {c['seed']} | {c['selected_step']} | {c['initial_development']['decision_regret']:.6f} | {c['selected_development']['decision_regret']:.6f} |")
lines+=['','Evaluation completed in one uninterrupted attempt: no committed evaluation prefix was resumed. Post-evaluation in-memory fingerprints matched the admitted checkpoints. Full per-episode observations, chosen utilities, predictions, probabilities and hidden scoring labels are retained in `evaluation.jsonl`; hidden labels are used only outside the policy for scoring.','',
        '## Interpretation and next hypothesis','',
        'This supports the bounded mechanism: modeling persistent source dependence and buying reference observations can correct shared errors in these synthetic worlds. It also shows why the next experiment should target unnecessary verification and robustness to independently corrupted observations. That future change needs a newly registered protocol and fresh evaluation data. This release is not retuned after seeing its challenge outcomes.','',
        'The priors, likelihoods, finite world support and acquisition teacher are supplied by the implementation. Only the acquisition approximation is learned. Results do not demonstrate AGI, open-domain factual reliability, a new foundation language model, or global novelty. Bootstrap intervals resample 96 episode clusters, averaging learned seeds within each episode; they do not establish general population guarantees.','',
        '![Frozen synthetic benchmark](evidence/benchmark.png)','',
        f"Protocol SHA-256: `{s['protocol_sha256']}`.",
        f"Evaluation SHA-256: `{s['evaluation_sha256']}`.",
        f"Training summary SHA-256: `{s['training_summary_sha256']}`.",'']
(ROOT/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.titleweight':'bold','figure.facecolor':'#f7f5ef','axes.facecolor':'#f7f5ef','text.color':'#262b26','axes.labelcolor':'#262b26'})
fig=plt.figure(figsize=(13,8.8),layout='constrained'); gs=fig.add_gridspec(2,2,height_ratios=[1,1.1]); ax=fig.add_subplot(gs[0,0]); bx=fig.add_subplot(gs[0,1]); cx=fig.add_subplot(gs[1,:])
colors=['#b8bcb0' if k not in ('learned','source_aware','reference_only') else {'learned':'#546b38','source_aware':'#608687','reference_only':'#c79854'}[k] for k in order]
y=np.arange(len(order)); ax.barh(y,[shared[k]['net_utility'] for k in order],color=colors); ax.set_yticks(y,[names[k] for k in order]); ax.invert_yaxis(); ax.set_xlim(0,1); ax.set_xlabel('Realized utility: weighted accuracy − paid cost'); ax.set_title('Shared faults: confirmation helps',loc='left',pad=15)
for i,k in enumerate(order): ax.text(shared[k]['net_utility']+.012,i,f"{shared[k]['net_utility']:.3f}",va='center',fontsize=9)
bx.barh(y,[100*shared[k]['confident_wrong'] for k in order],color=colors); bx.set_yticks(y,[names[k] for k in order]); bx.invert_yaxis(); bx.set_xlim(0,109); bx.set_xlabel('Weighted confidently wrong mass (%)'); bx.set_title('Confident error remains a separate measure',loc='left',pad=15)
for i,k in enumerate(order): bx.text(100*shared[k]['confident_wrong']+1.2,i,f"{100*shared[k]['confident_wrong']:.1f}%",va='center',fontsize=9)
families=p['families']; x=np.arange(len(families)); best_values=[max(v['net_utility'] for k,v in s['summaries'][f].items() if k!='learned') for f in families]
cx.bar(x-.24,[s['summaries'][f]['learned']['net_utility'] for f in families],.24,color='#546b38',label='Learned selector')
cx.bar(x,[s['summaries'][f]['source_aware']['net_utility'] for f in families],.24,color='#608687',label='Source-aware analytic')
cx.bar(x+.24,best_values,.24,color='#c79854',label='Best observed non-neural control')
cx.set_xticks(x,['Clean','Shared bias','Cheap outliers','Reference outliers','Bias drift','Compositional']); cx.set_ylim(0,1.16); cx.set_ylabel('Realized utility'); cx.set_title('All six conditions: learned acquisition does not beat the strongest control',loc='left',pad=15); cx.legend(loc='upper right',frameon=True,facecolor='#f7f5ef',framealpha=1,ncol=3,fontsize=9)
fig.suptitle('SZL FOUNDATION 004  |  Source-aware confirmation',fontsize=19,fontweight='bold',x=.02,ha='left')
fig.supxlabel('5,184 rollouts · 96 worlds/condition · 3 learned seeds · Synthetic finite-world experiment\nPrimary gain passed; clean-sensor guard failed. Bars are means; paired intervals are in RESULTS.md.',fontsize=10)
(ROOT/'evidence').mkdir(exist_ok=True); fig.savefig(ROOT/'evidence/benchmark.png',dpi=180); fig.savefig(ROOT/'evidence/benchmark.pdf'); plt.close(fig)
