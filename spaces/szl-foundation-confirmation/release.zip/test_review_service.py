"""Independent source/weight drift checks around actual runtime admission.

The fake inference body isolates admission behavior. These tests do not attest
to model performance, and their fixture bytes are never deserialized as weights.
"""
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from server import ConfirmationRuntime, canonical, sha


class RuntimeDriftReviewTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        for name in ('core.py', 'policy.py', 'experiment.py'):
            (self.root/name).write_text('# admission-only fixture\n')
        protocol = {'source_sha256': {name: sha(self.root/name)
                                     for name in ('core.py', 'policy.py', 'experiment.py')}}
        (self.root/'protocol.json').write_bytes(canonical(protocol))
        protocol_sha = sha(self.root/'protocol.json')
        (self.root/'protocol.sha256').write_text(protocol_sha+'\n')
        (self.root/'data-receipt.json').write_text('{"fixture": true}')
        rows = []
        for seed in (17, 23, 41):
            path = self.root/f'fixture-{seed}.safetensors'
            path.write_bytes(b'Never loaded as model weights')
            rows.append({'seed': seed, 'path': path.name, 'sha256': sha(path),
                         'protocol_sha256': protocol_sha,
                         'data_receipt_sha256': sha(self.root/'data-receipt.json'),
                         'trained_fingerprint': 'a'*64})
        (self.root/'training-summary.json').write_bytes(canonical({
            'schema': 'szl.confirmation.training/v1', 'protocol_sha256': protocol_sha,
            'checkpoints': rows}))
        self.runtime = ConfirmationRuntime(self.root)
        self.runtime._load_modules = lambda admitted: None
        self.request = {'seed': 899127, 'index': 1, 'family': 'clean',
                        'policy': 'source_aware', 'model_seed': 17}

    def tearDown(self):
        self.temporary.cleanup()

    def test_source_change_during_trial_cannot_produce_complete_binding(self):
        def inference(*args, **kwargs):
            (self.root/'core.py').write_text('# changed during inference\n')
            return {'fixture': True}
        self.runtime.experiment = SimpleNamespace(run_episode=inference)
        with self.assertRaisesRegex(ValueError, 'source mismatch'):
            self.runtime.run(self.request)

    def test_in_memory_model_mutation_is_rejected_after_inference(self):
        model = SimpleNamespace(value='a'*64)
        self.runtime.models[17] = model
        self.runtime.policy = SimpleNamespace(fingerprint=lambda m: m.value)
        def inference(*args, **kwargs):
            kwargs['model'].value = 'b'*64
            return {'fixture': True}
        self.runtime.experiment = SimpleNamespace(run_episode=inference)
        with self.assertRaisesRegex(ValueError, 'weights changed during inference'):
            self.runtime.run({**self.request, 'policy': 'learned'})

    def test_changed_cached_model_is_rejected_before_inference(self):
        self.runtime.models[17] = SimpleNamespace(value='b'*64)
        self.runtime.policy = SimpleNamespace(fingerprint=lambda m: m.value)
        def forbidden_inference(*args, **kwargs):
            raise AssertionError('Drifted model reached inference')
        self.runtime.experiment = SimpleNamespace(run_episode=forbidden_inference)
        with self.assertRaisesRegex(ValueError, 'Cached model differs'):
            self.runtime.run({**self.request, 'policy': 'learned'})


if __name__ == '__main__':
    unittest.main()
