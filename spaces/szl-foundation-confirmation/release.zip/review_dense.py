"""Independent dense enumeration check for the compact confirmation posterior.

The reference sums all 16**5 latent (bias, four shifts) states directly. It
does not use core.likelihoods, the compact update, or its joint calculation.
Run after the implementation is frozen; outputs a source-bound JSON receipt.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import core


class DenseReference:
    def __init__(self, public, correlated):
        self.worlds = np.indices((16, 16, 16, 16)).reshape(4, -1).T
        p0 = np.full(16, .2 / 15)
        p0[0] = .8
        world = .2 * p0[self.worlds].prod(axis=1)
        # Rebuild the 76-world prior independently from the public family masses.
        hypotheses = [(np.zeros(4, dtype=int), public['prior_family'][0])]
        for shift in range(1, 16):
            hypotheses.append((np.full(4, shift), public['prior_family'][1] / 15))
        for group in range(4):
            for shift in range(1, 16):
                value = np.zeros(4, dtype=int)
                value[group] = shift
                hypotheses.append((value, public['prior_family'][2] / 60))
        for value, probability in hypotheses:
            world[np.ravel_multi_index(tuple(value), (16, 16, 16, 16))] += .8 * probability
        self.bias_prior = np.full(16, .2 / 15)
        self.bias_prior[0] = .8
        self.posterior = self.bias_prior[:, None] * world[None, :]
        self.correlated = correlated
        self.mass = np.array(public['goal_mass'])
        self.costs = np.array(public['costs'])
        self.resources = np.array(public['resource_costs'])
        self.remaining = public['budget']

    def likelihood(self, action, label):
        source, group = divmod(action, 4)
        values = self.worlds[:, group]
        if source == 1:
            return np.broadcast_to(np.where(values == label, .98, .02 / 15), self.posterior.shape)
        if self.correlated:
            expected = (values[None, :] + np.arange(16)[:, None]) % 16
            return np.where(expected == label, .98, .02 / 15)
        # Independent bias on each reading, preserving the same one-reading marginal.
        probability = np.zeros(len(values))
        for bias, weight in enumerate(self.bias_prior):
            probability += weight * np.where((values + bias) % 16 == label, .98, .02 / 15)
        return np.broadcast_to(probability, self.posterior.shape)

    @staticmethod
    def marginals(distribution):
        world = distribution.sum(axis=0).reshape((16, 16, 16, 16))
        return np.stack([world.sum(axis=tuple(i for i in range(4) if i != g)) for g in range(4)])

    def observe(self, action, label, charge=True):
        self.posterior *= self.likelihood(action, label)
        self.posterior /= self.posterior.sum()
        if charge:
            self.remaining -= int(self.resources[action])

    def joint(self):
        result = np.empty((8, 16, 4, 16))
        for action in range(8):
            for label in range(16):
                result[action, label] = self.marginals(self.posterior * self.likelihood(action, label))
        return result


def run():
    start = time.perf_counter()
    public = {'goal_mass': [.1, .2, .3, .4], 'prior_family': [.21, .37, .42],
              'costs': [.025] * 4 + [.05] * 4, 'resource_costs': [1] * 4 + [2] * 4, 'budget': 4}
    max_errors = {'marginal': 0., 'bias': 0., 'joint': 0., 'utility': 0.}
    checks = []
    for correlated in (True, False):
        compact = core.Belief(public, correlation=correlated)
        dense = DenseReference(public, correlated)
        # The source-aware case sees mutually reinforcing inherited readings,
        # then a contradicting reference. The same data is used for the ablation.
        observations = [(0, 7, False), (1, 7, False), (2, 7, False), (3, 7, False),
                        (4, 0, True), (0, 7, True)]
        for step in (0, 4, 5, 6):
            already = len(compact.history)
            for index in range(already, step):
                action, label, charge = observations[index]
                observation = {'source': ('cheap', 'reference')[action // 4],
                               'group': action % 4, 'label': label,
                               'observation_id': f'dense-check-{index}'}
                compact.observe(observation, charge=charge)
                dense.observe(action, label, charge)
            cm = compact.marginal()
            dm = dense.marginals(dense.posterior)
            dj = dense.joint()
            cj = compact.observation_joint()
            direct_utility = (dj.max(axis=3) * dense.mass[None, None, :]).sum(axis=(1, 2))
            direct_utility -= dense.mass @ dm.max(axis=1)
            direct_utility -= dense.costs
            available = dense.resources <= dense.remaining
            actual_utility = compact.exact_utilities()
            errors = {'marginal': float(abs(cm-dm).max()),
                      'bias': float(abs(compact.bias_marginal()-dense.posterior.sum(axis=1)).max()),
                      'joint': float(abs(cj-dj).max()),
                      'utility': float(abs(actual_utility[available]-direct_utility[available]).max())}
            assert np.all(np.isneginf(actual_utility[~available]))
            assert all(value < 1e-10 for value in errors.values()), errors
            for key, value in errors.items():
                max_errors[key] = max(max_errors[key], value)
            checks.append({'correlated': correlated, 'observations': step, 'errors': errors})
    return {'status': 'PASS', 'latent_states_per_reference': 16**5,
            'posterior_states_checked': len(checks), 'action_response_joints_checked': len(checks)*8*16,
            'max_absolute_errors': max_errors, 'checks': checks,
            'elapsed_seconds': time.perf_counter()-start,
            'source_hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in (Path(core.__file__), Path(__file__))}}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='dense-review.json')
    args = parser.parse_args()
    result = run()
    Path(args.output).write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key != 'checks'}, indent=2))
