'use strict';
const byId = id => document.getElementById(id);
let currentReceipt = null;
let busy = false;
const familyNotes = {
  clean: 'Both channels follow their ordinary low-noise behavior.',
  shared_bias: 'Cheap observations share one hidden bias. Repeating the same source can repeat the same mistake.',
  independent_outliers: 'The cheap channel has more independent observation errors.',
  reference_outliers: 'The reference channel is deliberately noisier. Its name is not a guarantee of truth.',
  bias_drift: 'The cheap source bias changes during the episode, challenging the fixed-bias model.',
  compositional: 'Two groups change independently, challenging the structured world assumptions.'
};
const policyNotes = {
  source_aware: 'Exact one-step Bayesian decision rule with an explicit shared-source bias.',
  learned: 'A trained neural selector chooses observations; the belief update uses the explicit probabilistic model.',
  independent_bias: 'An ablation that treats cheap-source biases as independent across observations.',
  no_confirmation: 'Retains inherited observations without buying more evidence.',
  cheap_only: 'Restricts new observations to the cheaper channel.',
  reference_only: 'Restricts new observations to the reference channel.',
  random_mixed: 'Chooses affordable observations from both channels at random.'
};
const human = value => String(value).replaceAll('_', ' ');
const pct = value => Number.isFinite(value) ? `${(100 * value).toFixed(1)}%` : '—';
const number = value => Number.isFinite(value) ? value.toFixed(4) : '—';
function element(tag, text, className) {
  const result = document.createElement(tag);
  if (text !== undefined) result.textContent = text;
  if (className) result.className = className;
  return result;
}
async function api(path, options) {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function descriptions() {
  byId('family-description').textContent = familyNotes[byId('family').value];
  byId('policy-description').textContent = policyNotes[byId('policy').value];
  byId('model-seed').disabled = byId('policy').value !== 'learned';
}
async function refreshStatus() {
  try {
    const status = await api('/api/status');
    byId('connection').textContent = status.ready ? 'Local service ready' : 'Local service · awaiting verified build';
    byId('connection-dot').className = status.ready ? 'dot ready' : 'dot';
    byId('sources').textContent = status.ready ? 'Verified' : 'Unavailable';
    byId('checkpoints').textContent = String(status.checkpoints_verified || 0);
    byId('loaded').textContent = String((status.models_loaded || []).length);
    byId('status-message').textContent = status.ready ? 'Sources and saved weights are verified. A checkpoint loads into memory only when selected for a learned trial.' : (status.error || 'Waiting for a complete, source-bound build.');
    byId('run-trial').disabled = busy || status.busy || !status.ready;
    const list = byId('recent-trials'); list.replaceChildren();
    if (!status.recent_trials.length) list.append(element('p', 'No local trials have been saved yet.', 'muted'));
    for (const trial of status.recent_trials) {
      const button = element('button', undefined, 'recent-item');
      button.append(element('span', trial.request ? `${human(trial.request.family)} · ${human(trial.request.policy)}` : trial.id));
      button.append(element('small', `${trial.status} · ${trial.created_at ? new Date(trial.created_at).toLocaleString() : 'Integrity check failed'}`));
      button.disabled = trial.status === 'INVALID_RECEIPT';
      button.addEventListener('click', async () => {
        try { renderTrial(await api(`/api/trials/${encodeURIComponent(trial.id)}`)); }
        catch (error) { byId('trial-message').textContent = error.message; }
      });
      list.append(button);
    }
  } catch (error) {
    byId('connection').textContent = 'Service unavailable';
    byId('connection-dot').className = 'dot';
    byId('status-message').textContent = error.message;
    byId('run-trial').disabled = true;
  }
}
function renderTrial(receipt) {
  currentReceipt = receipt;
  byId('export').disabled = false;
  byId('trial-heading').textContent = `${human(receipt.request.family)} / ${human(receipt.request.policy)}`;
  byId('receipt-json').textContent = JSON.stringify(receipt, null, 2);
  byId('receipt-details').hidden = false;
  const result = receipt.result;
  for (const id of ['score-cards', 'prediction-section', 'history-section']) byId(id).hidden = !result;
  if (!result) { byId('trial-message').textContent = `Retained failed trial: ${receipt.error || receipt.status}`; return; }
  byId('trial-message').textContent = `Saved ${new Date(receipt.completed_at).toLocaleString()} · world ${receipt.request.seed} / episode ${receipt.request.index} · exploratory result`;
  const cards = byId('score-cards'); cards.replaceChildren();
  for (const [title, value] of [['Weighted accuracy', pct(result.accuracy)], ['Accuracy − cost', number(result.net_utility)], ['Confident error', pct(result.confident_wrong)], ['Paid observation cost', number(result.paid_cost)]]) {
    const card = element('div', undefined, 'score'); card.append(element('span', title), element('strong', value)); cards.append(card);
  }
  const predictions = byId('predictions'); predictions.replaceChildren();
  for (let group = 0; group < (result.prediction || []).length; group++) {
    const item = element('div', undefined, 'prediction');
    item.append(element('span', `GROUP ${group}`), element('strong', `Label ${result.prediction[group]}`), element('small', `${pct(result.confidence?.[group])} confidence`));
    const meter = document.createElement('meter'); meter.min = 0; meter.max = 1; meter.value = result.confidence?.[group] || 0; meter.setAttribute('aria-label', `Group ${group} final confidence`); item.append(meter); predictions.append(item);
  }
  byId('bias').textContent = `Final P(cheap-source bias = 0): ${pct(result.bias_probabilities?.[0])} · resources used: ${result.resources_used ?? '—'} / 4 · paid probes: ${result.probes ?? '—'} · high-confidence coverage: ${pct(result.coverage)}`;
  const history = byId('history'); history.replaceChildren();
  for (const [index, observation] of (result.history || []).entries()) {
    const row = element('tr');
    for (const value of [index + 1, `${observation.source} / ${observation.charged ? 'paid' : 'inherited'}`, observation.group, observation.label, pct(observation.predictive_probability_before_update), observation.remaining_resources, pct(observation.bias_probability_zero)]) row.append(element('td', String(value)));
    history.append(row);
  }
}
async function benchmark() {
  try {
    const result = await api('/api/results');
    if (!result.available) { byId('benchmark-message').textContent = result.message; return; }
    const data = result.data;
    byId('benchmark-message').textContent = data.primary.overall_pass ? 'Registered outcome: overall gate passed.' : 'Registered outcome: overall gate failed. The shared-fault gain passed; clean-sensor regression exceeded the allowed limit.';
    byId('benchmark-json').textContent = JSON.stringify(data, null, 2);
    byId('benchmark-details').hidden = false;
    const target = byId('benchmark-tables'); target.replaceChildren();
    target.append(element('p', 'Shared-fault learned utility gain: ' + number(data.primary.mean_gain) + ' · paired 95% interval [' + data.primary.ci95.map(number).join(', ') + ']. Clean utility change: ' + number(data.clean_guard.mean_gain) + '.', 'field-note'));
    target.append(element('p', 'The learned selector did not establish superiority over the strongest control. Each condition has 96 worlds; learned means average three trained seeds. Utility is weighted accuracy minus incremental cost.', 'field-note'));
    for (const family of ['shared_bias', 'clean', 'independent_outliers', 'reference_outliers', 'bias_drift', 'compositional']) {
      const details = element('details'); details.open = family === 'shared_bias';
      details.append(element('summary', human(family)));
      const wrapper = element('div', undefined, 'table-scroll'), table = element('table'), head = element('tr'), thead = element('thead'), body = element('tbody');
      for (const label of ['Policy', 'Accuracy', 'Utility', 'Paid cost', 'Confident error', 'Paid references']) head.append(element('th', label));
      thead.append(head); table.append(thead);
      for (const policy of ['learned', 'source_aware', 'reference_only', 'independent_bias', 'no_confirmation', 'cheap_only', 'random_mixed']) {
        const metrics = data.summaries[family][policy], row = element('tr');
        for (const value of [human(policy), pct(metrics.accuracy), number(metrics.net_utility), number(metrics.paid_cost), pct(metrics.confident_wrong), number(metrics.reference_probes)]) row.append(element('td', value));
        body.append(row);
      }
      table.append(body); wrapper.append(table); details.append(wrapper); target.append(details);
    }
  } catch (error) { byId('benchmark-message').textContent = error.message; }
}
byId('family').addEventListener('change', descriptions);
byId('policy').addEventListener('change', descriptions);
byId('trial-form').addEventListener('submit', async event => {
  event.preventDefault();
  const request = {seed: Number(byId('seed').value), index: Number(byId('episode-index').value), family: byId('family').value, policy: byId('policy').value, model_seed: Number(byId('model-seed').value)};
  busy = true; byId('run-trial').disabled = true; byId('trial-message').textContent = 'Running inference and saving the observation receipt…';
  try { renderTrial(await api('/api/trial', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(request)})); }
  catch (error) { byId('trial-message').textContent = error.message; }
  finally { busy = false; await refreshStatus(); }
});
byId('export').addEventListener('click', () => {
  if (!currentReceipt) return;
  const url = URL.createObjectURL(new Blob([JSON.stringify(currentReceipt, null, 2)], {type: 'application/json'}));
  const link = document.createElement('a'); link.href = url; link.download = `szl-confirmation-${currentReceipt.id}.json`; link.click(); URL.revokeObjectURL(url);
});
descriptions(); refreshStatus(); benchmark();
