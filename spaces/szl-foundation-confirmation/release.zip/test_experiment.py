import copy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import experiment
import numpy as np
import torch
from core import make_episode, FAMILIES
from experiment import POLICIES, run_episode, seeded_belief, generate_states, validation
from policy import Selector, encode, fingerprint, save, load

class ExperimentTests(unittest.TestCase):
    def test_encoding_has_no_latent_truth_or_posterior_input(self):
        episode=make_episode(481,7,'shared_bias'); belief=seeded_belief(episode)
        original=encode(episode.public,belief.history,belief.remaining_resources)
        episode.truth[:]=13; episode.bias=11; episode.family='compositional'
        history=copy.deepcopy(belief.history)
        for row in history: row['surprise_nats']=999; row['bias_probability_zero']=0; row['observation_id']='arbitrary'
        np.testing.assert_array_equal(original,encode(episode.public,history,belief.remaining_resources))
        history[0]['label']=(history[0]['label']+1)%16
        self.assertFalse(np.array_equal(original,encode(episode.public,history,belief.remaining_resources)))

    def test_raw_input_refuses_unsupported_contract(self):
        episode=make_episode(12,0,'clean'); belief=seeded_belief(episode)
        bad=copy.deepcopy(episode.public); bad['truth']=[0]*4
        with self.assertRaises(ValueError): encode(bad,belief.history,4)
        bad=copy.deepcopy(episode.public); bad['resource_costs'][0]=2
        with self.assertRaises(ValueError): encode(bad,belief.history,4)
        with self.assertRaises(ValueError): encode(episode.public,belief.history*3,4)

    def test_all_baselines_obey_same_inherited_and_paid_contract(self):
        for family in FAMILIES:
            for policy in POLICIES[:-1]:
                row=run_episode(145,5,family,policy,include_history=True)
                self.assertEqual(row['inherited_observations'],4)
                self.assertLessEqual(row['resources_used'],4)
                self.assertAlmostEqual(row['paid_cost'],row['cheap_probes']*.025+row['reference_probes']*.05)
                self.assertEqual(row['probes'],row['cheap_probes']+row['reference_probes'])
                self.assertEqual(row['net_utility'],row['accuracy']-row['paid_cost'])
                self.assertLessEqual(len(row['history']),8)
                if policy=='cheap_only': self.assertEqual(row['reference_probes'],0)
                if policy=='reference_only': self.assertEqual(row['cheap_probes'],0)
                if policy=='no_confirmation': self.assertEqual(row['probes'],0)

    def test_neural_executes_real_model_and_preserves_weights(self):
        model=Selector()
        with torch.no_grad():
            for parameter in model.parameters(): parameter.zero_()
            model.network[-1].bias[4]=1
        before=fingerprint(model)
        row=run_episode(52,8,'shared_bias','learned',model,True)
        self.assertEqual(row['reference_probes'],2)
        self.assertEqual(row['resources_used'],4)
        self.assertEqual(fingerprint(model),before)
        with torch.no_grad(): model.network[-1].bias.fill_(-1)
        self.assertEqual(run_episode(52,8,'shared_bias','learned',model)['probes'],0)
        with self.assertRaises(ValueError): run_episode(52,8,'shared_bias','learned')

    def test_serialization_and_modified_checkpoint_rejection(self):
        model=Selector()
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'weights.safetensors'; digest=save(path,model,{'seed':7})
            restored,metadata=load(path,digest)
            self.assertEqual(metadata,{'seed':7}); self.assertEqual(fingerprint(model),fingerprint(restored))
            path.write_bytes(path.read_bytes()+b'broken')
            with self.assertRaises(ValueError): load(path,digest)

    def test_data_is_deterministic_disjoint_and_affordable(self):
        a=generate_states(903,8); b=generate_states(903,8); c=generate_states(904,8)
        for key in a: np.testing.assert_array_equal(a[key],b[key])
        self.assertFalse(set(a['identities']) & set(c['identities']))
        self.assertEqual(a['x'].shape,(8,208)); self.assertTrue(a['mask'].any(axis=1).all())
        self.assertTrue(np.isfinite(a['x']).all()); self.assertTrue(np.isfinite(a['y']).all())
        self.assertGreaterEqual(validation(Selector(),a)['decision_regret'],0)

    def test_completed_evaluation_is_immutable_and_rejects_new_models(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            experiment.write_json(root/'protocol.json',{'test':'bounded-fixture'})
            experiment.write_json(root/'training-summary.json',{'checkpoints':[]})
            p={'families':['clean'],'episodes_per_family':1,'policies':['no_confirmation'],'model_seeds':[],'test_seed':731}
            with patch.object(experiment,'ROOT',root),patch.object(experiment,'loaded_models',return_value={}):
                experiment.evaluate(p)
                before=(root/'evaluation-receipt.json').read_bytes()
                experiment.evaluate(p)
                self.assertEqual(before,(root/'evaluation-receipt.json').read_bytes())
                rows=(root/'evaluation.jsonl').read_text()
                self.assertIn('history',rows); self.assertIn('observation_id',rows)
                experiment.write_json(root/'training-summary.json',{'checkpoints':[],'generation':2})
                with self.assertRaisesRegex(ValueError,'binding changed'): experiment.evaluate(p)

    def test_unbound_evaluation_rows_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            experiment.write_json(root/'protocol.json',{})
            experiment.write_json(root/'training-summary.json',{'checkpoints':[]})
            (root/'evaluation.jsonl').write_text('{}\n')
            with patch.object(experiment,'ROOT',root),patch.object(experiment,'loaded_models',return_value={}):
                with self.assertRaisesRegex(ValueError,'Unbound'): experiment.evaluate({})

if __name__=='__main__': unittest.main()
