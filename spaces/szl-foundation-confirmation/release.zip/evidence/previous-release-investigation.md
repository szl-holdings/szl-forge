# Previous release integrity investigation

Observed: 2026-09-24T15:31:59.724680+00:00

The archived v0.3 ZIP matches the supplied SHA-256: `5ee7324bbff9ff5fea8ac47da4927a31e4d0dd27f862c71a090ffd76933f2bc9`.

Archive manifest verification: 107/107 files match both size and SHA-256. The archived release manifest is byte-identical to the directory manifest. ZIP CRC validation passed.

Current extracted directory verification: 105/107 files match. Strict verification fails.

| Path | Current directory | Archive | Classification |
| --- | --- | --- | --- |
| `foundation-workbench/evidence/journal-snapshot.sqlite3-shm` | missing | match | volatile-sqlite-sidecar |
| `foundation-workbench/evidence/journal-snapshot.sqlite3-wal` | missing | match | volatile-sqlite-sidecar |

All manifest-covered non-sidecar files, including the SQLite database, retain their declared bytes. There is no byte-level evidence of a database or source change among the 107 manifest entries.

SQLite `-shm` and `-wal` files are connection-lifecycle sidecars. Their absence still violates this release manifest because the manifest explicitly included them. This pass can establish only the observed file bytes or absence; it does not establish which earlier process altered or removed them.

Parent reported an earlier strict verification failure on changed evidence/journal-snapshot.sqlite3-shm. This investigation records current bytes; the earlier changed SHM state was not independently observed in this pass.

Read file bytes and ZIP members only. No SQLite connection was opened and no previous release file or service was modified. Disk observations are sequential, not an atomic filesystem snapshot.

Detailed expected and observed size/hash values for every entry are retained in `previous-release-investigation.json`.
