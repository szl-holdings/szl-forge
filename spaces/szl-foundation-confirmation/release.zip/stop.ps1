$ErrorActionPreference = 'Stop'
$labRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$serverScript = Join-Path $labRoot 'server.py'
$receiptPath = Join-Path $labRoot 'state\service.json'
if (-not (Test-Path -LiteralPath $receiptPath)) { Write-Output 'No service process receipt exists for this lab.'; exit 0 }
$serviceReceipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
if ($serviceReceipt.server_script -ne $serverScript) { throw 'Process receipt belongs to another lab directory.' }
$ownedProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$serviceReceipt.pid)" -ErrorAction SilentlyContinue
if (-not $ownedProcess) { Write-Output 'The recorded process is no longer running.'; exit 0 }
$expectedPort = '--port\s+' + [regex]::Escape([string]$serviceReceipt.port) + '(?:\s|$)'
$expectedCreation = ([datetime]$serviceReceipt.process_created).ToUniversalTime()
if ($ownedProcess.CommandLine -notmatch [regex]::Escape($serverScript) -or $ownedProcess.CommandLine -notmatch $expectedPort -or $ownedProcess.ExecutablePath -ne $serviceReceipt.executable -or $ownedProcess.CreationDate.ToUniversalTime() -ne $expectedCreation) {
    throw 'Process ownership could not be verified. No process was stopped.'
}
Stop-Process -Id $ownedProcess.ProcessId -ErrorAction Stop
Wait-Process -Id $ownedProcess.ProcessId -Timeout 10 -ErrorAction SilentlyContinue
Write-Output "Stopped this lab's service process $($ownedProcess.ProcessId). Trial receipts remain in state/trials."
