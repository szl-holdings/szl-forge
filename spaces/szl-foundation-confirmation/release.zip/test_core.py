"""Math and policy-boundary tests; all data fixtures are separate from challenges."""
import copy
import unittest
import numpy as np

from core import Belief, FEATURE_DIM, FAMILIES, make_episode, score


def observation(source, group, label, name):
    return {"source": source, "group": group, "label": label, "observation_id": name}


class DenseOracle:
    """Independent enumeration of all 16**5 world/bias states.

    Builds priors and likelihoods from their definitions; does not use compact
    component arrays, indicators, likelihood tables, or action-value code.
    """
    def __init__(self, public, correlation=True):
        self.worlds = np.indices((16, 16, 16, 16), dtype=np.int16).reshape(4, -1).T
        self.bias = np.arange(16)
        self.bias_prior = np.full(16, .2 / 15)
        self.bias_prior[0] = .8
        self.mass = np.asarray(public["goal_mass"])
        self.costs = np.asarray(public["costs"])
        self.correlation = correlation
        family = np.asarray(public["prior_family"])
        count = (self.worlds != 0).sum(axis=1)
        world_prior = .2 * np.where(self.worlds == 0, .8, .2 / 15).prod(axis=1)
        world_prior[count == 0] += .8 * family[0]
        global_world = (self.worlds == self.worlds[:, :1]).all(axis=1) & (count == 4)
        world_prior[global_world] += .8 * family[1] / 15
        world_prior[count == 1] += .8 * family[2] / 60
        self.posterior = world_prior[:, None] * self.bias_prior[None, :]

    def like(self, action, y):
        source, group = divmod(action, 4)
        if source == 0 and not self.correlation:
            bias_probability = self.bias_prior[(y - self.worlds[:, group]) % 16]
            return ((1 - .02) * bias_probability + .02 / 15 * (1 - bias_probability))[:, None]
        latent = self.worlds[:, group, None] + (self.bias[None, :] if source == 0 else 0)
        return np.where(latent % 16 == y, .98, .02 / 15)

    def observe(self, action, y):
        self.posterior *= self.like(action, y)
        self.posterior /= self.posterior.sum()

    def marginal(self, posterior=None):
        weights = (self.posterior if posterior is None else posterior).sum(axis=1)
        return np.array([np.bincount(self.worlds[:, g], weights=weights, minlength=16) for g in range(4)])

    def utility(self, action):
        current = self.mass @ self.marginal().max(axis=1)
        expected = 0.0
        for y in range(16):
            # Keep response mass unnormalized; equivalently p(y) * A(after y).
            after = self.posterior * self.like(action, y)
            expected += self.mass @ self.marginal(after).max(axis=1)
        return expected - current - self.costs[action]


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.episode = make_episode(718331, 8, "shared_bias")
        self.public = self.episode.public

    def test_prior_normalization_and_dense_enumeration(self):
        belief, oracle = Belief(self.public), DenseOracle(self.public)
        self.assertAlmostEqual(belief.W.sum() + belief.Q.sum(), 1)
        np.testing.assert_allclose(belief.U.sum(axis=2), 1)
        np.testing.assert_allclose(belief.marginal(), oracle.marginal(), atol=3e-13, rtol=1e-10)
        np.testing.assert_allclose(belief.bias_marginal(), oracle.posterior.sum(axis=0), atol=3e-12, rtol=1e-10)

    def test_mixed_history_and_exact_action_values_against_full_enumeration(self):
        belief, oracle = Belief(self.public), DenseOracle(self.public)
        for g, label in enumerate((7, 7, 7, 11)):
            belief.observe(observation("cheap", g, label, f"inherited-{g}"), charge=False)
            oracle.observe(g, label)
        belief.observe(observation("reference", 0, 0, "reference-0"))
        oracle.observe(4, 0)
        np.testing.assert_allclose(belief.marginal(), oracle.marginal(), atol=2e-12, rtol=1e-9)
        np.testing.assert_allclose(belief.bias_marginal(), oracle.posterior.sum(axis=0), atol=2e-12, rtol=1e-9)
        utility = belief.exact_utilities()
        for action in range(8):
            self.assertAlmostEqual(utility[action], oracle.utility(action), places=10)

    def test_independent_bias_ablation_dense_posterior_and_utilities(self):
        belief, oracle = Belief(self.public, correlation=False), DenseOracle(self.public, correlation=False)
        for g, label in enumerate((6, 6, 6, 6)):
            belief.observe(observation("cheap", g, label, f"inherited-{g}"), charge=False)
            oracle.observe(g, label)
        belief.observe(observation("reference", 1, 0, "reference-1"))
        oracle.observe(5, 0)
        np.testing.assert_allclose(belief.marginal(), oracle.marginal(), atol=2e-12, rtol=1e-9)
        np.testing.assert_allclose(belief.bias_marginal(), np.array([.8] + [.2/15]*15), atol=2e-12)
        for action in (0, 5):
            self.assertAlmostEqual(belief.exact_utilities()[action], oracle.utility(action), places=10)

    def test_joint_marginals_and_predictive_normalization(self):
        belief = Belief(self.public)
        for g in range(4):
            belief.observe(self.episode.observe(g, charge=False), charge=False)
        joint = belief.observation_joint()
        np.testing.assert_allclose(joint.sum(axis=1), np.broadcast_to(belief.marginal(), (8, 4, 16)), atol=1e-12)
        np.testing.assert_allclose(joint.sum(axis=(1, 3)), np.ones((8, 4)), atol=1e-12)
        prediction_by_target = joint.sum(axis=3)
        np.testing.assert_allclose(prediction_by_target, np.broadcast_to(prediction_by_target[:, :, :1], (8, 16, 4)), atol=1e-12)

    def test_reference_revises_other_groups_through_shared_bias(self):
        belief = Belief(self.public)
        for g in range(4):
            belief.observe(observation("cheap", g, 9, f"inherited-{g}"), charge=False)
        before = belief.marginal()[1:, 0].copy()
        bias_before = belief.bias_marginal()[9]
        belief.observe(observation("reference", 0, 0, "confirm"))
        self.assertTrue(np.all(belief.marginal()[1:, 0] > before + .5))
        self.assertGreater(belief.bias_marginal()[9], bias_before)

    def test_repeated_cheap_is_not_independent_confirmation(self):
        belief = Belief(self.public)
        for g in range(4):
            belief.observe(observation("cheap", g, 9, f"inherited-{g}"), charge=False)
        cheap, reference = copy.deepcopy(belief), copy.deepcopy(belief)
        cheap.observe(observation("cheap", 0, 9, "repeat"))
        reference.observe(observation("reference", 0, 0, "reference"))
        self.assertLess(cheap.marginal()[1:, 0].mean(), reference.marginal()[1:, 0].mean() - .5)

    def test_fixed_observation_order_invariance(self):
        a, b = Belief(self.public), Belief(self.public)
        inherited = [observation("cheap", g, value, f"inherit-{g}") for g, value in enumerate((4, 4, 2, 4))]
        for obs in inherited:
            a.observe(obs, charge=False)
        for obs in reversed(inherited):
            b.observe(obs, charge=False)
        paid = [observation("reference", 1, 0, "paid-a"), observation("reference", 2, 14, "paid-b")]
        for obs in paid:
            a.observe(obs)
        for obs in reversed(paid):
            b.observe(obs)
        np.testing.assert_allclose(a.marginal(), b.marginal(), atol=1e-13)
        np.testing.assert_allclose(a.bias_marginal(), b.bias_marginal(), atol=1e-13)

    def test_same_likelihood_more_expensive_is_never_better(self):
        belief = Belief(self.public)
        belief.likelihood[1] = belief.likelihood[0]
        utilities = belief.exact_utilities()
        np.testing.assert_allclose(utilities[:4] - utilities[4:], .025, atol=1e-12)

    def test_expected_information_gain_in_accuracy_is_nonnegative(self):
        for family in FAMILIES:
            episode = make_episode(712992, 5, family)
            belief = Belief(episode.public)
            for g in range(4):
                belief.observe(episode.observe(g, charge=False), charge=False)
            self.assertGreaterEqual(float((belief.exact_utilities() + belief.costs).min()), -1e-12)

    def test_budget_and_duplicate_id_rejection_are_atomic(self):
        belief = Belief(self.public)
        obs = observation("reference", 1, 3, "first")
        belief.observe(obs)
        before = belief.marginal().copy()
        with self.assertRaises(ValueError):
            belief.observe(obs)
        self.assertEqual(belief.remaining_resources, 2)
        np.testing.assert_array_equal(before, belief.marginal())
        belief.observe(observation("cheap", 2, 0, "second"))
        self.assertEqual(belief.remaining_resources, 1)
        self.assertTrue(np.all(belief.available[:4]))
        self.assertTrue(np.all(~belief.available[4:]))
        with self.assertRaises(ValueError):
            belief.observe(observation("reference", 3, 0, "unaffordable"))
        belief.observe(observation("cheap", 0, 0, "third"))
        self.assertIsNone(belief.choose())
        self.assertTrue(np.all(np.isneginf(belief.exact_utilities())))
        self.assertAlmostEqual(belief.paid_cost, .1)

    def test_stop_when_every_action_cost_exceeds_possible_accuracy_gain(self):
        public = copy.deepcopy(self.public)
        public["costs"] = [2.0] * 8
        belief = Belief(public)
        self.assertIsNone(belief.choose())
        self.assertEqual(belief.paid_cost, 0)
        self.assertEqual(belief.history, [])

    def test_four_inherited_reports_are_free_and_bounded(self):
        belief = Belief(self.public)
        for g in range(4):
            belief.observe(self.episode.observe(g, charge=False), charge=False)
        self.assertEqual(self.episode.remaining_resources, 4)
        self.assertEqual(belief.remaining_resources, 4)
        self.assertEqual(belief.paid_cost, 0)
        with self.assertRaises(ValueError):
            belief.observe(observation("cheap", 0, 0, "extra"), charge=False)
        with self.assertRaises(ValueError):
            self.episode.observe(0, charge=False)
        with self.assertRaises(ValueError):
            Belief(self.public).observe(observation("reference", 0, 0, "free-reference"), charge=False)
        belief.observe(self.episode.observe(0))
        report = score(belief, self.episode)
        self.assertEqual(report["inherited_observations"], 4)
        self.assertEqual(report["probes"], 1)
        self.assertEqual(report["resources_used"], 1)

    def test_inherited_reports_cannot_be_added_after_paid_actions(self):
        belief = Belief(self.public)
        belief.observe(self.episode.observe(0))
        with self.assertRaises(ValueError):
            belief.observe(observation("cheap", 1, 0, "late"), charge=False)
        with self.assertRaises(ValueError):
            self.episode.observe(1, charge=False)

    def test_counterfactual_tape_is_action_visit_indexed(self):
        a, b = make_episode(111231, 8, "shared_bias"), make_episode(111231, 8, "shared_bias")
        for g in range(4):
            self.assertEqual(a.observe(g, charge=False), b.observe(g, charge=False))
        a_first, a_second = a.observe(1), a.observe(4)
        b_second, b_first = b.observe(4), b.observe(1)
        self.assertEqual(a_first, b_first)
        self.assertEqual(a_second, b_second)

    def test_drift_only_after_first_paid_cheap_reading(self):
        episode = make_episode(233819, 0, "bias_drift")
        episode.noise_offsets[:] = 0
        for g in range(4):
            self.assertEqual(episode.observe(g, charge=False)["label"], int((episode.truth[g] + episode.bias) % 16))
        first = episode.observe(0)
        second = episode.observe(0)
        self.assertEqual(first["label"], int((episode.truth[0] + episode.bias) % 16))
        self.assertEqual(second["label"], int((episode.truth[0] + episode.second_bias) % 16))
        self.assertNotEqual(first["label"], second["label"])

    def test_more_visits_after_inherited_evidence_fit_tape(self):
        episode = make_episode(818182, 7, "shared_bias")
        belief = Belief(episode.public)
        for g in range(4):
            belief.observe(episode.observe(g, charge=False), charge=False)
        for _ in range(4):
            belief.observe(episode.observe(0))
        self.assertEqual(len(belief.history), 8)
        self.assertEqual(episode.visits[0], 5)
        self.assertEqual(len({r["observation_id"] for r in belief.history}), 8)

    def test_public_features_are_sufficient_for_one_step_teacher(self):
        belief = Belief(self.public)
        for g in range(4):
            belief.observe(self.episode.observe(g, charge=False), charge=False)
        features = belief.features()
        self.assertEqual(features.shape, (8, FEATURE_DIM))
        self.assertTrue(np.isfinite(features).all())
        joint = features[:, :1024].reshape(8, 16, 4, 16).astype(np.float64)
        marginal = features[:, 1024:1088].reshape(8, 4, 16).astype(np.float64)
        mass = features[:, 1088:1092].astype(np.float64)
        expected = (joint.max(axis=3) * mass[:, None, :]).sum(axis=(1, 2))
        initial = (marginal.max(axis=2) * mass).sum(axis=1)
        reconstructed = expected - initial - features[:, 1092]
        np.testing.assert_allclose(reconstructed, belief.exact_utilities(), atol=1e-7, rtol=1e-6)

    def test_policy_input_schema_rejects_hidden_fields(self):
        for name in ("truth", "family", "bias", "seed"):
            public = copy.deepcopy(self.public)
            public[name] = 1
            with self.assertRaises(ValueError):
                Belief(public)
        belief = Belief(self.public)
        obs = observation("cheap", 0, 0, "legal")
        obs["truth"] = 0
        with self.assertRaises(ValueError):
            belief.observe(obs)
        self.assertEqual(belief.history, [])

    def test_input_validation(self):
        for action in (-1, 8, True, 1.5):
            with self.assertRaises(ValueError):
                self.episode.observe(action)
        for name, value in (("goal_mass", [1, 0, 0, -1]), ("costs", [float("nan")] * 8),
                            ("resource_costs", [1.5] * 8), ("budget", True), ("prior_family", [1, 1, 1])):
            public = copy.deepcopy(self.public)
            public[name] = value
            with self.assertRaises(ValueError):
                Belief(public)

    def test_score_no_abstention_inflation_and_proper_losses(self):
        belief = Belief(self.public)
        report = score(belief, self.episode)
        expected = float(belief.mass @ (belief.marginal().argmax(axis=1) == self.episode.truth))
        self.assertAlmostEqual(report["accuracy"], expected)
        self.assertAlmostEqual(report["net_utility"], expected)
        self.assertGreaterEqual(report["brier"], 0)
        self.assertGreaterEqual(report["log_loss"], 0)
        self.assertGreaterEqual(report["coverage"], report["confident_wrong"])


if __name__ == "__main__":
    unittest.main()
