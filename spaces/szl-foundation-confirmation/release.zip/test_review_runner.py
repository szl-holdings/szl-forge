"""Independent regression checks for evaluation-generation admission and resume.

These use temporary directories, fresh untrained fixture models and a separate
fixture seed. They never read or consume the registered challenge results.
"""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import experiment
from policy import Selector, fingerprint, save, sha


class ReviewRunnerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.models = {17: Selector()}
        self.protocol = {'families': ['clean'], 'episodes_per_family': 2,
                         'policies': ['learned'], 'model_seeds': [17], 'test_seed': 71299177}
        (self.root/'protocol.json').write_text(json.dumps(self.protocol), encoding='utf-8')
        (self.root/'data-receipt.json').write_text('{"fixture": true}', encoding='utf-8')
        metadata = {'seed': 17, 'protocol_sha256': sha(self.root/'protocol.json'),
                    'data_receipt_sha256': sha(self.root/'data-receipt.json')}
        model_path = self.root/'fixture.safetensors'
        model_digest = save(model_path, self.models[17], metadata)
        self.training_summary = {'schema': 'szl.confirmation.training/v1',
                                 'protocol_sha256': metadata['protocol_sha256'],
                                 'fixture_generation': 1,
                                 'checkpoints': [{'seed': 17, 'path': model_path.name,
                                                  'sha256': model_digest,
                                                  'trained_fingerprint': fingerprint(self.models[17])}]}
        (self.root/'training-summary.json').write_text(json.dumps(self.training_summary), encoding='utf-8')
        self.root_patch = patch.object(experiment, 'ROOT', self.root)
        self.models_patch = patch.object(experiment, 'loaded_models', return_value=self.models)
        self.root_patch.start()
        self.models_patch.start()

    def tearDown(self):
        self.models_patch.stop()
        self.root_patch.stop()
        self.temporary.cleanup()

    def interrupted_prefix(self):
        original = experiment.run_episode
        calls = []
        def interrupt_second(*args, **kwargs):
            calls.append(1)
            if len(calls) == 2:
                raise RuntimeError('Deliberate fixture interruption')
            return original(*args, **kwargs)
        with patch.object(experiment, 'run_episode', side_effect=interrupt_second):
            with self.assertRaisesRegex(RuntimeError, 'fixture interruption'):
                experiment.evaluate(self.protocol)
        self.assertEqual(len((self.root/'evaluation.jsonl').read_text().splitlines()), 1)
        return (self.root/'evaluation.jsonl').read_bytes()

    def test_resume_rejects_changed_training_generation(self):
        prefix = self.interrupted_prefix()
        self.training_summary['fixture_generation'] = 2
        (self.root/'training-summary.json').write_text(json.dumps(self.training_summary), encoding='utf-8')
        with self.assertRaises(ValueError):
            experiment.evaluate(self.protocol)
        self.assertEqual(prefix, (self.root/'evaluation.jsonl').read_bytes())

    def test_resume_preserves_prefix_and_full_observations(self):
        before = {key: fingerprint(value) for key, value in self.models.items()}
        prefix = self.interrupted_prefix()
        experiment.evaluate(self.protocol)
        content = (self.root/'evaluation.jsonl').read_bytes()
        self.assertTrue(content.startswith(prefix))
        rows = [json.loads(line) for line in content.splitlines()]
        self.assertEqual(len(rows), 2)
        for row in rows:
            self.assertIn('history', row)
            self.assertEqual(sum(not r['charged'] for r in row['history']), 4)
            self.assertEqual(sum(r['charged'] for r in row['history']), row['probes'])
        self.assertEqual(before, {key: fingerprint(value) for key, value in self.models.items()})

    def test_completed_evaluation_is_verified_without_rewriting(self):
        experiment.evaluate(self.protocol)
        journal = (self.root/'evaluation.jsonl').read_bytes()
        receipt = (self.root/'evaluation-receipt.json').read_bytes()
        with patch.object(experiment, 'run_episode', side_effect=AssertionError('Completed run was replayed')):
            experiment.evaluate(self.protocol)
        self.assertEqual(journal, (self.root/'evaluation.jsonl').read_bytes())
        self.assertEqual(receipt, (self.root/'evaluation-receipt.json').read_bytes())


if __name__ == '__main__':
    unittest.main()
