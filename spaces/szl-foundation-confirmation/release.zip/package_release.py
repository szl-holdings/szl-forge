"""Seal and package one immutable standalone release after evaluation completes.

Run only when all intended source, review, UI, and result files are final:
  python package_release.py seal --output ../SZL-foundation-confirmation-v0.4.zip
Existing manifests and archives are never overwritten. Runtime state is excluded.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import zipfile

from verify_release import (EXCLUDED_DIRS, EXCLUDED_SUFFIXES, EXCLUDED_FILES, MANIFEST, SCHEMA,
                            included_files, require, sha, verify_archive,
                            verify_bindings, verify_directory)


def build_manifest(root):
    files = included_files(root)
    required = {"core.py", "policy.py", "experiment.py", "test_core.py", "test_experiment.py",
                "README.md", "RESULTS.md", "requirements.txt", "start.ps1", "package_release.py",
                "verify_release.py", "DESIGN_REVIEW.md", "INDEPENDENT_REVIEW.md", "INDEPENDENT_REVIEW.json",
                "research/GLOBAL_RESEARCH.md", "research/AGENCY_RESEARCH.md"}
    require(required <= set(files), f"Release is unfinished: missing {sorted(required-set(files))}")
    def read(name):
        require(name in files, f"Missing evidence artifact: {name}")
        return files[name].read_bytes()
    bindings = verify_bindings(read)
    return {"schema": SCHEMA, "version": "0.4", "created_utc": datetime.now(timezone.utc).isoformat(),
            "scope": "Standalone local synthetic confirmation research; internal hashes are not independent signatures",
            "excluded_directories": sorted(EXCLUDED_DIRS), "excluded_suffixes": sorted(EXCLUDED_SUFFIXES),
            "excluded_files": sorted(EXCLUDED_FILES),
            "bindings": bindings,
            "files": {name: {"sha256": sha(path.read_bytes()), "bytes": path.stat().st_size} for name, path in files.items()}}


def seal(root, output):
    root = Path(root).resolve(strict=True)
    output = Path(output).resolve()
    require(root not in output.parents, "Archive must be outside the release directory")
    receipt_path = output.with_suffix(".receipt.json")
    require(not output.exists() and not receipt_path.exists() and not (root / MANIFEST).exists(),
            "Refusing to overwrite a sealed manifest, archive, or receipt")
    manifest = build_manifest(root)
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()
    with (root / MANIFEST).open("xb") as handle:
        handle.write(manifest_bytes)
    directory_check = verify_directory(root)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, mode="x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted([*manifest["files"], MANIFEST]):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (root / name).read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    archive_check = verify_archive(output)
    require(directory_check["manifest_sha256"] == archive_check["manifest_sha256"], "Archive manifest differs from directory")
    # Repeat byte verification only because packaging could race a late writer.
    verify_directory(root)
    receipt = {"schema": "szl.confirmation.package-receipt/v1", "archive": output.name,
               "created_utc": datetime.now(timezone.utc).isoformat(), "directory": directory_check, "archive_check": archive_check}
    with receipt_path.open("x", encoding="utf-8") as handle:
        json.dump(receipt, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("check", "seal"))
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.action == "check":
        value = build_manifest(args.root)
        print(json.dumps({"status": "READY_TO_SEAL", "files": len(value["files"]), "bindings": value["bindings"]}, indent=2))
    else:
        require(args.output is not None, "--output is required to seal")
        print(json.dumps(seal(args.root, args.output), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
