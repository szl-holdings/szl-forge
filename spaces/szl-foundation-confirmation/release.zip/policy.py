"""Trainable acquisition model using only public priors and observed history."""
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from safetensors.torch import save_file, load_file

FEATURES=208


def encode(public, history, remaining):
    """Eight history slots: source, group, label, occupied, newly purchased."""
    if set(public)!={'goal_mass','prior_family','costs','resource_costs','budget'}:
        raise ValueError('Unexpected public fields')
    if public['budget']!=4 or public['resource_costs']!=[1]*4+[2]*4:
        raise ValueError('Unsupported resource contract')
    if type(remaining) is not int or not 0<=remaining<=4:
        raise ValueError('Invalid remaining resources')
    if len(history)>8: raise ValueError('History exceeds eight observations')
    value=np.zeros(FEATURES,dtype=np.float32)
    value[:4]=public['goal_mass']; value[4:7]=public['prior_family']
    value[7:15]=public['costs']; value[15]=remaining/4
    for i,record in enumerate(history):
        source=record['source']; group=record['group']; label=record['label']
        if source not in ('cheap','reference') or type(group) is not int or group not in range(4) or type(label) is not int or label not in range(16):
            raise ValueError('Invalid public observation')
        start=16+24*i
        value[start+int(source=='reference')]=1
        value[start+2+group]=1; value[start+6+label]=1
        value[start+22]=1; value[start+23]=float(record['charged'])
    if not np.isfinite(value).all(): raise ValueError('Nonfinite input')
    return value


class Selector(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.network=torch.nn.Sequential(torch.nn.Linear(FEATURES,96),torch.nn.SiLU(),
            torch.nn.Linear(96,64),torch.nn.SiLU(),torch.nn.Linear(64,8))
    def forward(self,x): return self.network(x)
    @property
    def parameter_count(self): return sum(x.numel() for x in self.parameters())


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fingerprint(model):
    h=hashlib.sha256()
    for name,tensor in sorted(model.state_dict().items()):
        h.update(name.encode()); h.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def save(path,model,metadata):
    path=Path(path); temporary=path.with_suffix('.tmp')
    save_file({k:v.detach().cpu().contiguous() for k,v in model.state_dict().items()},str(temporary),
        metadata={'schema':'szl.confirmation.selector/v1','source_sha256':sha(__file__),'metadata':json.dumps(metadata,sort_keys=True)})
    temporary.replace(path)
    return sha(path)


def load(path,expected_sha256):
    from safetensors import safe_open
    if sha(path)!=expected_sha256: raise ValueError('Checkpoint bytes changed')
    with safe_open(str(path),framework='pt',device='cpu') as f: metadata=f.metadata()
    if metadata.get('schema')!='szl.confirmation.selector/v1' or metadata.get('source_sha256')!=sha(__file__):
        raise ValueError('Checkpoint schema/source mismatch')
    model=Selector(); state=load_file(str(path),device='cpu')
    if any(v.dtype!=torch.float32 or not torch.isfinite(v).all() for v in state.values()): raise ValueError('Invalid weights')
    model.load_state_dict(state,strict=True); model.eval()
    return model,json.loads(metadata['metadata'])
