"""Exact finite source-aware confirmation model; no learned world discovery.

Actions 0..3 buy cheap observations and 4..7 buy independent references.
The true world and sensor regimes live only in Episode and the score function.
Belief receives public metadata and the observations actually purchased.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import copy
import numpy as np

N_GROUPS, N_LABELS, N_ACTIONS = 4, 16, 8
FAMILIES = ("clean", "shared_bias", "independent_outliers", "reference_outliers", "bias_drift", "compositional")
SOURCE_NAMES = ("cheap", "reference")
COSTS = np.array([.025] * 4 + [.05] * 4, dtype=np.float64)
RESOURCE_COSTS = np.array([1] * 4 + [2] * 4, dtype=np.int64)
INDEPENDENT_WEIGHT, UNCHANGED_PROBABILITY, BIAS_ZERO_PROBABILITY = .2, .8, .8
NOISE = .02
_hypotheses = [np.zeros(4, dtype=np.int64)]
_hypotheses.extend(np.full(4, shift, dtype=np.int64) for shift in range(1, 16))
for _group in range(4):
    for _shift in range(1, 16):
        _row = np.zeros(4, dtype=np.int64)
        _row[_group] = _shift
        _hypotheses.append(_row)
HYPOTHESES = np.stack(_hypotheses)
INDICATORS = np.eye(16, dtype=np.float64)[HYPOTHESES]
BIAS_PRIOR = np.full(16, (1 - BIAS_ZERO_PROBABILITY) / 15)
BIAS_PRIOR[0] = BIAS_ZERO_PROBABILITY
# 1024 predictive-joint entries + 64 current marginals + 4 goal weights +
# candidate price, resource cost, remaining resources, source, availability.
FEATURE_DIM = 1097


def _integer(value, name, lower, upper):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or not lower <= value <= upper:
        raise ValueError(f"Invalid {name}")
    return int(value)


def _probabilities(values, count, name):
    result = np.asarray(values, dtype=np.float64)
    if result.shape != (count,) or not np.isfinite(result).all() or (result < 0).any() or not np.isclose(result.sum(), 1, atol=1e-12, rtol=0):
        raise ValueError(f"Invalid {name}")
    return result.copy()


def likelihoods(correlation=True):
    """P(y | bias b, true shift x), independently generated fresh noise."""
    cheap = np.full((16, 16, 16), NOISE / 15, dtype=np.float64)
    reference = cheap.copy()
    for b in range(16):
        for x in range(16):
            cheap[b, x, (b + x) % 16] = 1 - NOISE
            reference[b, x, x] = 1 - NOISE
    if not correlation:
        # Correlation ablation: redraw bias from the prior on every reading.
        # Thus a posterior reference cannot update the cheap source's bias.
        cheap[:] = np.einsum("b,bxy->xy", BIAS_PRIOR, cheap)[None, :, :]
    return np.stack((cheap, reference))


class Belief:
    """Exact mixture over structured worlds and bias-conditioned product worlds."""

    def __init__(self, public, correlation=True):
        if set(public) != {"goal_mass", "costs", "resource_costs", "budget", "prior_family"}:
            raise ValueError("Unexpected public metadata fields")
        self.mass = _probabilities(public["goal_mass"], 4, "goal mass")
        family = _probabilities(public["prior_family"], 3, "family prior")
        self.costs = np.asarray(public["costs"], dtype=np.float64).copy()
        raw_resources = np.asarray(public["resource_costs"])
        if self.costs.shape != (8,) or not np.isfinite(self.costs).all() or (self.costs < 0).any():
            raise ValueError("Invalid costs")
        if raw_resources.shape != (8,) or not np.issubdtype(raw_resources.dtype, np.integer) or (raw_resources < 1).any():
            raise ValueError("Invalid resource costs")
        self.resource_costs = raw_resources.astype(np.int64, copy=True)
        self.budget = _integer(public["budget"], "budget", 0, 4)
        prior = np.concatenate(([family[0]], np.full(15, family[1] / 15), np.full(60, family[2] / 60)))
        self.W = (1 - INDEPENDENT_WEIGHT) * prior[:, None] * BIAS_PRIOR[None, :]
        self.Q = INDEPENDENT_WEIGHT * BIAS_PRIOR.copy()
        self.U = np.full((16, 4, 16), (1 - UNCHANGED_PROBABILITY) / 15)
        self.U[:, :, 0] = UNCHANGED_PROBABILITY
        self.correlation = bool(correlation)
        self.likelihood = likelihoods(self.correlation)
        self.remaining_resources = self.budget
        self.paid_cost = 0.0
        self.history = []
        self._observation_ids = set()
        self._inherited_groups = set()
        self._paid_started = False
        self._joint_cache = None

    @property
    def available(self):
        return self.resource_costs <= self.remaining_resources

    def marginal(self):
        return np.einsum("h,hgx->gx", self.W.sum(axis=1), INDICATORS) + np.einsum("b,bgx->gx", self.Q, self.U)

    def bias_marginal(self):
        return self.W.sum(axis=0) + self.Q

    def observation_joint(self):
        """Return P(Y_action=y, X_group=x) with shape (8,16,4,16)."""
        if self._joint_cache is None:
            result = np.empty((8, 16, 4, 16), dtype=np.float64)
            flat_indicators = INDICATORS.reshape(76, 64)
            for action in range(8):
                source, group = divmod(action, 4)
                like = self.likelihood[source]
                # Per-hypothesis response mass, marginalized over shared bias.
                chosen = like[:, HYPOTHESES[:, group], :].transpose(1, 0, 2)
                response_mass = (self.W[:, :, None] * chosen).sum(axis=1)
                joint = (response_mass.T @ flat_indicators).reshape(16, 4, 16)
                predictive = np.einsum("bx,bxy->by", self.U[:, group], like)
                independent = np.einsum("b,by,bgx->ygx", self.Q, predictive, self.U)
                # Same latent variable on both sides: diagonal identity.
                independent[:, group, :] = np.einsum("b,bx,bxy->yx", self.Q, self.U[:, group], like)
                result[action] = joint + independent
            self._joint_cache = result
        return self._joint_cache.copy()

    def exact_utilities(self):
        marginal = self.marginal()
        current = float(self.mass @ marginal.max(axis=1))
        expected = np.einsum("ayg,g->a", self.observation_joint().max(axis=3), self.mass)
        result = expected - current - self.costs
        result[~self.available] = -np.inf
        return result

    def choose(self):
        utility = self.exact_utilities()
        action = int(np.argmax(utility))
        return action if utility[action] > 0 else None

    def features(self):
        """Sufficient public predictive context for the exact one-step teacher.

        Joint features include cross-group/shared-bias correlations. They are
        model-derived probabilities, not the world's true latent variables.
        """
        joint = self.observation_joint().reshape(8, 1024)
        marginal = np.broadcast_to(self.marginal().reshape(1, 64), (8, 64))
        mass = np.broadcast_to(self.mass, (8, 4))
        action_info = np.column_stack((self.costs, self.resource_costs / 4,
                                      np.full(8, self.remaining_resources / 4),
                                      np.arange(8) // 4, self.available.astype(float)))
        return np.concatenate((joint, marginal, mass, action_info), axis=1).astype(np.float32)

    def observe(self, observation, charge=True):
        if type(charge) is not bool:
            raise ValueError("Charge must be boolean")
        if set(observation) != {"source", "group", "label", "observation_id"}:
            raise ValueError("Unexpected observation fields")
        source_name = observation["source"]
        if source_name not in SOURCE_NAMES:
            raise ValueError("Unknown source")
        source = SOURCE_NAMES.index(source_name)
        group = _integer(observation["group"], "group", 0, 3)
        label = _integer(observation["label"], "label", 0, 15)
        observation_id = observation["observation_id"]
        if not isinstance(observation_id, str) or not 1 <= len(observation_id) <= 128:
            raise ValueError("Invalid observation ID")
        if observation_id in self._observation_ids:
            raise ValueError("Duplicate observation ID")
        action = source * 4 + group
        if charge and not self.available[action]:
            raise ValueError("Observation exceeds resource budget")
        if not charge and (source != 0 or group in self._inherited_groups or self._paid_started):
            raise ValueError("Inherited evidence must be one cheap report per group before paid actions")
        like = self.likelihood[source, :, :, label]
        structured = self.W * like[:, HYPOTHESES[:, group]].T
        independent_evidence = np.einsum("bx,bx->b", self.U[:, group], like)
        independent_weights = self.Q * independent_evidence
        evidence = float(structured.sum() + independent_weights.sum())
        if not np.isfinite(evidence) or evidence <= 0:
            raise ArithmeticError("Invalid predictive evidence")
        self.W = structured / evidence
        self.Q = independent_weights / evidence
        self.U[:, group] *= like / independent_evidence[:, None]
        self._observation_ids.add(observation_id)
        if charge:
            self.remaining_resources -= int(self.resource_costs[action])
            self.paid_cost += float(self.costs[action])
            self._paid_started = True
        else:
            self._inherited_groups.add(group)
        self._joint_cache = None
        self.history.append({**observation, "action": action, "charged": charge,
            "predictive_probability_before_update": evidence,
            "surprise_nats": float(-np.log(evidence)),
            "paid_cost_total": self.paid_cost,
            "remaining_resources": self.remaining_resources,
            "bias_probability_zero": float(self.bias_marginal()[0])})


@dataclass
class Episode:
    public: dict
    truth: np.ndarray
    family: str
    truth_family: str
    bias: int
    second_bias: int
    noise_offsets: np.ndarray
    visits: np.ndarray = field(default_factory=lambda: np.zeros(8, dtype=np.int64))
    remaining_resources: int = 4
    cheap_calls: int = 0
    inherited_groups: set = field(default_factory=set)
    paid_started: bool = False

    def observe(self, action, charge=True):
        if type(charge) is not bool:
            raise ValueError("Charge must be boolean")
        action = _integer(action, "action", 0, 7)
        cost = int(self.public["resource_costs"][action])
        if charge and cost > self.remaining_resources:
            raise ValueError("Action exceeds resource budget")
        source, group = divmod(action, 4)
        if not charge and (source != 0 or group in self.inherited_groups or self.paid_started):
            raise ValueError("Inherited evidence must be one cheap report per group before paid actions")
        visit = int(self.visits[action])
        realized_bias = 0
        if source == 0:
            realized_bias = self.second_bias if self.family == "bias_drift" and self.cheap_calls > 0 else self.bias
        label = int((self.truth[group] + realized_bias + self.noise_offsets[action, visit]) % 16)
        self.visits[action] += 1
        if charge:
            self.remaining_resources -= cost
            self.cheap_calls += int(source == 0)
            self.paid_started = True
        else:
            self.inherited_groups.add(group)
        return {"source": SOURCE_NAMES[source], "group": group, "label": label,
                "observation_id": f"{SOURCE_NAMES[source]}:{group}:{visit}"}

    def clone(self):
        return copy.deepcopy(self)


def make_episode(seed, index, family):
    seed = _integer(seed, "seed", 0, 2**32 - 1)
    index = _integer(index, "index", 0, 2**32 - 1)
    if family not in FAMILIES:
        raise ValueError("Unknown sensor family")
    rng = np.random.default_rng(np.random.SeedSequence([seed, index, FAMILIES.index(family)]))
    truth = np.zeros(4, dtype=np.int64)
    truth_family = ("unchanged", "global", "local")[index % 3]
    if family == "compositional":
        truth_family = "two_groups"
        groups = rng.choice(4, size=2, replace=False)
        truth[groups] = rng.integers(1, 16, size=2)
    elif truth_family == "global":
        truth[:] = rng.integers(1, 16)
    elif truth_family == "local":
        truth[int(rng.integers(4))] = rng.integers(1, 16)
    bias = int(rng.integers(1, 16)) if family in ("shared_bias", "reference_outliers", "bias_drift", "compositional") else 0
    second_bias = int((bias + rng.integers(1, 16)) % 16)
    mass = rng.dirichlet(np.full(4, .7))
    public = {"goal_mass": mass.tolist(), "costs": COSTS.tolist(),
              "resource_costs": RESOURCE_COSTS.tolist(), "budget": 4,
              "prior_family": [1/3, 1/3, 1/3]}
    # Noise is assigned to an action and visit, never to policy execution order.
    # Bias drift is deliberately time-dependent, separate from this noise tape.
    rates = np.full((8, 8), NOISE)
    if family == "independent_outliers":
        rates[:4] = .25
    if family == "reference_outliers":
        rates[4:] = .25
    draws = rng.random((8, 8))
    offsets = np.where(draws < rates, rng.integers(1, 16, size=(8, 8)), 0)
    return Episode(public, truth, family, truth_family, bias, second_bias, offsets)


def score(belief, episode, confidence_threshold=.8):
    """Truth is used only after decisions, outside the acquisition policy."""
    if not 0 <= confidence_threshold <= 1:
        raise ValueError("Invalid confidence threshold")
    marginal = belief.marginal()
    prediction = marginal.argmax(axis=1)
    confidence = marginal.max(axis=1)
    correct = prediction == episode.truth
    covered = confidence >= confidence_threshold
    mass = belief.mass
    accuracy = float(mass @ correct)
    coverage = float(mass @ covered)
    truth_probability = marginal[np.arange(4), episode.truth]
    brier = float(mass @ ((marginal - np.eye(16)[episode.truth]) ** 2).sum(axis=1))
    return {"accuracy": accuracy, "paid_cost": belief.paid_cost,
        "net_utility": accuracy - belief.paid_cost, "coverage": coverage,
        "selective_accuracy": float(mass @ (correct & covered) / coverage) if coverage > 0 else None,
        "confident_wrong": float(mass @ (~correct & covered)), "brier": brier,
        "log_loss": float(-mass @ np.log(np.maximum(truth_probability, 1e-12))),
        "probes": sum(row["charged"] for row in belief.history),
        "inherited_observations": sum(not row["charged"] for row in belief.history),
        "resources_used": belief.budget - belief.remaining_resources,
        "prediction": prediction.tolist(), "confidence": confidence.tolist(),
        "probabilities": marginal.tolist(), "bias_probabilities": belief.bias_marginal().tolist()}
