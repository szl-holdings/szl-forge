# Independent implementation and mathematical review

Reviewed **24 September 2026** by a collaborating agent who did not author `core.py` or `test_core.py`. This is internal technical review, not external replication or institutional peer review.

**Disposition: the reviewed core, exact one-step mathematics, and training/evaluation controller pass review. No blocking defect remains in that scope.** This disposition does not certify the application or claim that a scientific performance criterion has been met.

## Evidence actually checked

- Read `core.py` and every test in `test_core.py`; read the raw-history encoder design separately.
- Independently executed the implementation's **20 tests: all passed in 5.112 seconds**. Tests cover normalization, mixed-source updates, dependence ablation, cross-group revision, inherited evidence, resource accounting, duplicate rejection, acquisition order, drift, scoring, input boundaries and action values.
- Authored and ran a separate [dense reference](review_dense.py), without calling the implementation's likelihood builder, compact posterior update or joint calculation. It explicitly enumerates **1,048,576 latent states**: all four group shifts and the common bias.
- Checked both the shared-bias model and the independent-bias ablation at four states each: prior; four inherited cheap reports; a contradicting reference; and another cheap report. This compares **eight posterior states and 1,024 action/response joint slices**.
- Maximum absolute discrepancies were `1.034e-13` for world marginals, `2.443e-15` for bias probabilities, `8.205e-14` for predictive joints and `7.739e-14` for action utilities. The declared tolerance was `1e-10`. The run took 32.001 seconds. [Exact numerical receipt](dense-review.json).

The checked core SHA-256 is `573740e2f3e138b82508b49e29ad55c11e2a6e29c07fd44fe49f973628632c69`. The tests SHA-256 is `55e615ab2ae352f16f2f257928f3b7b89ced189e9d5bb5cd9f69275b43d9b3db`. Any changes to these files require assessing whether this review remains applicable.

## Mathematical assessment

The representation retains one episode-level bias across cheap observations. Conditional independence of the product-world component is preserved by conditioning on that bias. Its update and the structured-world update share the same evidence normalizer. Cross-group predictive joints integrate the shared latent bias; same-group joints correctly use the identity of the latent variable instead of multiplying two independent copies.

The acquisition value is the expected increase in goal-weighted Bayes classification accuracy minus the observation price. The calculation uses unnormalized observation/world joints, avoiding divisions by tiny predictive probabilities. It correctly masks unaffordable actions and stops when no positive net one-step value remains. **It is a greedy one-step policy, not a globally optimal sequential planner.** A sequence can be valuable even when its first observation has no immediate positive value.

The independent-bias ablation preserves the same marginal bias prior for each cheap reading, but redraws that bias independently in its model. It therefore tests a dependence assumption. It does not merely fix bias to zero. Its unchanged latent-bias marginal is expected because that retained bias variable does not influence its cheap observation likelihood.

## Fairness and interpretation

1. Four inherited cheap reports are equally available before paid decisions. They have zero incremental acquisition cost because they are existing evidence, not because cheap sensing is free. Further cheap readings cost one resource unit and `.025` utility; references cost two units and `.05`. All policies must receive the same initial reports and four-unit cap in the runner.
2. “Reference-only” and “cheap-only” should describe **paid acquisition restrictions**. A reference-only policy still starts with inherited cheap reports. Stale memory is intentionally an information-ignoring baseline, so beating it alone cannot demonstrate superior acquisition.
3. The noise tape is indexed by action and visit. Non-drift cases therefore retain paired counterfactual observations across different action orders. In `bias_drift`, the first paid cheap query triggers later bias change. This is explicitly an **action-dependent stress condition**; identical queries after different histories need not return the same biased value.
4. The balanced challenge conditions do not sample the model's bias prior as an unconditional population. For example, `shared_bias` forces a nonzero bias while the belief assigns 80% prior probability to zero bias. Per-condition performance remains meaningful, but posterior confidence is conditional on modeling assumptions, not a guaranteed calibrated probability for the challenge mixture.
5. Compositional worlds are outside the 76 structured hypotheses but inside the full support of the independent component. Describe them as outside the structured family, not outside all model support. Independent-outlier, reference-outlier and drift conditions deliberately violate the assumed observation process.
6. Lower confident-error mass can arise from lower coverage. Keep all-goal accuracy, cost, net utility, coverage and confidence errors separate. The reviewed score computes accuracy on all groups, without counting abstention as correctness.

## Information boundary

`Belief` accepts a narrow public schema; truth, actual bias, condition labels and future noise are not inputs. Observation labels are noisy relative shifts visible to the policy. Hidden world values are used by `Episode` to generate responses and by `score` after decisions. The runner must preserve that separation and must not expose episode indices, family names or hidden noise tapes to the learned selector.

The raw-history MLP is a different input path from the optional `Belief.features()` predictive-joint features. A claim of learning directly from public history requires using the former. A learned observation selector backed by this programmed Bayesian predictor remains a hybrid system; neither component learns new world rules in the reviewed design.

## Training and evaluation controller follow-up

Read `policy.py`, `experiment.py` and `test_experiment.py` before freezing. The selector has 26,792 parameters and receives 208 features containing public priors, goals, prices, remaining budget and observation history. The encoder ignores hidden truth, condition labels, episode indices, observation IDs and Bayesian posterior diagnostics. Development decision regret selects checkpoints; teacher utilities supervise training; the test seed is separate. This is supervised acquisition distillation, not reinforcement learning or end-to-end learning of the predictor.

The initial review found a release-integrity defect: a resumed journal was bound to the protocol but not its original checkpoint generation. This could mix old and new model results and emit a misleading unchanged-weights receipt. Before freezing, the author added a protocol/training-summary/checkpoint attempt record written before the first row, an OS-owned process lock, exact resume admission, and verification of completed evaluations without replay or receipt replacement. Full observation/action histories are now retained. Initial SafeTensors are saved before updates, alongside selected checkpoints and changed-parameter evidence.

Three independently authored [runner regression tests](test_review_runner.py) passed in **1.745 seconds**. They witness rejection of a changed training generation without modifying the prefix; valid interrupted-run continuation with full histories; and completed-run verification without replay or rewriting. Their first run failed because the review fixtures omitted the checkpoint schema now required by admission. The fixture was corrected to provide actual saved model/checkpoint metadata; production code was not weakened.

The report verifies artifact provenance. Paired bootstrap uses episodes as clusters and averages trained seeds within each episode. The strongest non-neural control is reselected inside each bootstrap draw, and learned-versus-analytic comparisons are explicit. The primary learned-versus-independent-bias comparison changes both inference assumptions and acquisition, so it is a joint-system comparison; winning it alone cannot establish a better learned acquisition algorithm.

Reviewed controller SHA-256: `a763286c6e29dd041ff8e09a3c49f6376e3c08383d5be38788d4b81f65854a11`. Reviewed selector SHA-256: `02705491ed34ca23ef2e900768ad33dc96903c16729a9981ad72475bf4379919`. Remaining release work is witnessed training/evaluation, result parity and application integration; their eventual outcomes must be reported separately from this code review.
