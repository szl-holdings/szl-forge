"""Frozen, reproducible training and paired evaluation of costed confirmation."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
from contextlib import contextmanager
import numpy as np
import torch
from core import Belief, FAMILIES, make_episode, score
from policy import Selector, encode, fingerprint, load, save, sha

ROOT=Path(__file__).resolve().parent
POLICIES=('no_confirmation','independent_bias','source_aware','cheap_only','reference_only','random_mixed','learned')
METRICS=('accuracy','paid_cost','net_utility','coverage','confident_wrong','brier','log_loss','probes','resources_used','cheap_probes','reference_probes')
torch.set_num_threads(2)

def write_json(path,value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
    temp.replace(path)

def read_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))

@contextmanager
def evaluation_lock():
    """OS-owned lock releases on process exit; an old lock file is harmless."""
    with (ROOT/'.evaluation.lock').open('a+b') as handle:
        handle.seek(0); handle.write(b'0'); handle.flush(); handle.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        try: yield
        finally:
            handle.seek(0)
            if os.name=='nt': msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
            else: fcntl.flock(handle.fileno(),fcntl.LOCK_UN)

def verify_protocol():
    p=read_json(ROOT/'protocol.json')
    if sha(ROOT/'protocol.json')!=(ROOT/'protocol.sha256').read_text().strip(): raise ValueError('Protocol changed')
    for name,digest in p['source_sha256'].items():
        if sha(ROOT/name)!=digest: raise ValueError(f'Source changed: {name}')
    return p

def initialize():
    if (ROOT/'protocol.json').exists(): return verify_protocol()
    p={'schema':'szl.confirmation.protocol/v1','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
       'source_sha256':{name:sha(ROOT/name) for name in ('core.py','policy.py','experiment.py')},
       'model_seeds':[17,23,41],'training_seed':9242410,'development_seed':9242411,'test_seed':9242412,
       'training_states':4096,'development_states':768,'episodes_per_family':96,'families':list(FAMILIES),
       'training_families':['clean','shared_bias'],'training_family_probability':[.5,.5],
       'steps':1600,'batch_size':128,'learning_rate':.002,'validation_interval':200,'optimizer':'AdamW weight_decay=0.01',
       'architecture':'208 raw public history features -> 96 SiLU -> 64 SiLU -> 8 utilities; 26792 parameters',
       'teacher':'Exact one-step expected weighted accuracy gain minus observation price; explicit Bayesian predictor',
       'selection':'Minimum development decision regret; development masked MSE breaks ties; no test feedback',
       'inherited':'Four cheap reports, one per group, available to every policy before additional spending',
       'budget':4,'resource_costs':[1]*4+[2]*4,'prices':[.025]*4+[.05]*4,
       'policies':list(POLICIES),'neural_stop':'Stop when highest affordable predicted utility <= 0',
       'random':'Uniform affordable paid actions until budget exhaustion',
       'pairing':'Same world and action/visit noise tape across policies; drift changes bias after first paid cheap observation',
       'primary':{'family':'shared_bias','candidate':'learned','baseline':'independent_bias','metric':'net_utility',
                  'required_gain':.03,'required_ci_low':0,'clean_max_utility_regret':.01,
                  'bootstrap':'2000 resamples of whole episode clusters, averaging model seeds within each episode', 'bootstrap_seed':9242413},
       'secondary':'Report all six families and all baselines including no extra evidence, cheap only and reference only; analytic source-aware comparison is separate',
       'truth_boundary':'Synthetic finite worlds and programmed likelihoods; learned acquisition only; no AGI or biological/operational-domain claim'}
    write_json(ROOT/'protocol.json',p)
    (ROOT/'protocol.sha256').write_text(sha(ROOT/'protocol.json')+'\n')
    return p

def seeded_belief(episode,correlation=True):
    belief=Belief(episode.public,correlation=correlation)
    for group in range(4): belief.observe(episode.observe(group,charge=False),charge=False)
    return belief

def run_episode(seed,index,family,policy,model=None,include_history=False):
    if policy not in POLICIES: raise ValueError('Unknown policy')
    episode=make_episode(seed,index,family)
    belief=seeded_belief(episode,correlation=policy!='independent_bias')
    initial=score(belief,episode)
    rng=np.random.default_rng(np.random.SeedSequence([seed,index,FAMILIES.index(family),991]))
    while belief.available.any() and policy!='no_confirmation':
        if policy=='learned':
            if model is None: raise ValueError('Learned policy requires verified weights')
            with torch.no_grad(): utilities=model(torch.from_numpy(encode(episode.public,belief.history,belief.remaining_resources))[None])[0].numpy().astype(float)
            if not np.isfinite(utilities).all(): raise ValueError('Nonfinite neural utility')
            utilities[~belief.available]=-np.inf
        elif policy=='random_mixed':
            utilities=np.full(8,-np.inf); utilities[int(rng.choice(np.flatnonzero(belief.available)))]=1
        else:
            utilities=belief.exact_utilities()
            if policy=='cheap_only': utilities[4:]=-np.inf
            if policy=='reference_only': utilities[:4]=-np.inf
        action=int(np.argmax(utilities))
        if utilities[action]<=0: break
        observation=episode.observe(action)
        belief.observe(observation)
        if include_history: belief.history[-1]['selected_utility']=float(utilities[action])
    result=score(belief,episode)
    result.update({'policy':policy,'seed':seed,'episode_index':index,'family':family,
        'cheap_probes':sum(r['charged'] and r['source']=='cheap' for r in belief.history),
        'reference_probes':sum(r['charged'] and r['source']=='reference' for r in belief.history),
        'initial_accuracy':initial['accuracy'],'initial_confident_wrong':initial['confident_wrong']})
    if include_history:
        result.update({'history':belief.history,'public':episode.public,'truth':episode.truth.tolist(),
                       'initial_prediction':initial['prediction'],'initial_confidence':initial['confidence']})
    return result

def generate_states(seed,count):
    features=[]; targets=[]; masks=[]; identities=[]
    for index in range(count):
        rng=np.random.default_rng(np.random.SeedSequence([seed,index,779]))
        family=('clean','shared_bias')[int(rng.integers(2))]
        episode=make_episode(seed,index,family); belief=seeded_belief(episode)
        for _ in range(int(rng.integers(4))):
            # Retain a state with at least one feasible action for supervised acquisition.
            affordable=np.flatnonzero(belief.resource_costs<belief.remaining_resources)
            if not len(affordable): break
            action=int(rng.choice(affordable)); belief.observe(episode.observe(action))
        utility=belief.exact_utilities(); mask=belief.available
        features.append(encode(episode.public,belief.history,belief.remaining_resources))
        targets.append(np.where(mask,utility,0)); masks.append(mask); identities.append(f'{seed}:{index}:{family}')
        if (index+1)%1024==0: print(f'data seed={seed} states={index+1}',flush=True)
    return {'x':np.asarray(features,dtype=np.float32),'y':np.asarray(targets,dtype=np.float32),
            'mask':np.asarray(masks,dtype=bool),'identities':np.asarray(identities)}

def data(p):
    target=ROOT/'data'; target.mkdir(exist_ok=True)
    for split in ('training','development'):
        path=target/f'{split}.npz'
        if path.exists(): raise ValueError('Refusing to overwrite generated data')
        values=generate_states(p[f'{split}_seed'],p[f'{split}_states']); np.savez_compressed(path,**values)
    receipt={'schema':'szl.confirmation.data/v1','protocol_sha256':sha(ROOT/'protocol.json'),
             'files':{f'data/{name}.npz':sha(target/f'{name}.npz') for name in ('training','development')}}
    write_json(ROOT/'data-receipt.json',receipt)

def read_data(p):
    receipt=read_json(ROOT/'data-receipt.json')
    if receipt['protocol_sha256']!=sha(ROOT/'protocol.json'): raise ValueError('Data protocol mismatch')
    for name,digest in receipt['files'].items():
        if sha(ROOT/name)!=digest: raise ValueError('Data hash mismatch')
    train=dict(np.load(ROOT/'data/training.npz',allow_pickle=False)); dev=dict(np.load(ROOT/'data/development.npz',allow_pickle=False))
    if set(train['identities']) & set(dev['identities']): raise ValueError('Overlapping split identities')
    return train,dev

def validation(model,values):
    with torch.no_grad(): prediction=model(torch.from_numpy(values['x'])).numpy()
    masked=np.where(values['mask'],prediction,-np.inf); actions=masked.argmax(1)
    executed=masked[np.arange(len(actions)),actions]>0
    utility=np.where(executed,values['y'][np.arange(len(actions)),actions],0)
    optimal=np.maximum(0,np.where(values['mask'],values['y'],-np.inf).max(1))
    mse=float(np.square(prediction-values['y'])[values['mask']].mean())
    return {'decision_regret':float((optimal-utility).mean()),'masked_mse':mse,
            'mean_teacher_utility_of_decision':float(utility.mean())}

def train(p):
    if (ROOT/'training-summary.json').exists(): raise ValueError('Refusing to overwrite trained release')
    values,dev=read_data(p); checkpoints=[]; (ROOT/'models').mkdir(exist_ok=True)
    x=torch.from_numpy(values['x']); y=torch.from_numpy(values['y']); mask=torch.from_numpy(values['mask'])
    for seed in p['model_seeds']:
        torch.manual_seed(seed); rng=np.random.default_rng(seed); model=Selector(); initial=fingerprint(model)
        initial_state={k:v.clone() for k,v in model.state_dict().items()}; initial_dev=validation(model,dev)
        initial_path=ROOT/f'models/initial-selector-{seed}.safetensors'
        initial_digest=save(initial_path,model,{'seed':seed,'phase':'initial','protocol_sha256':sha(ROOT/'protocol.json')})
        optimizer=torch.optim.AdamW(model.parameters(),lr=p['learning_rate'],weight_decay=.01)
        best=None; curve=[]; start=time.time()
        for step in range(1,p['steps']+1):
            indices=torch.from_numpy(rng.integers(len(x),size=p['batch_size']))
            predicted=model(x[indices]); loss=((predicted-y[indices])**2)[mask[indices]].mean()
            if not torch.isfinite(loss): raise ArithmeticError('Nonfinite training loss')
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            if step%p['validation_interval']==0:
                metrics=validation(model,dev); curve.append({'step':step,**metrics})
                rank=(metrics['decision_regret'],metrics['masked_mse'])
                if best is None or rank<best[0]: best=(rank,step,{k:v.detach().clone() for k,v in model.state_dict().items()},metrics)
        model.load_state_dict(best[2]); model.eval(); final=fingerprint(model)
        if initial==final: raise AssertionError('Weights did not change')
        changed=sum(int((v!=initial_state[k]).sum()) for k,v in model.state_dict().items())
        metadata={'seed':seed,'selected_step':best[1],'protocol_sha256':sha(ROOT/'protocol.json'),
                  'data_receipt_sha256':sha(ROOT/'data-receipt.json'),'parameters':model.parameter_count}
        path=ROOT/f'models/selector-{seed}.safetensors'; digest=save(path,model,metadata)
        restored,restored_meta=load(path,digest)
        if fingerprint(restored)!=final or restored_meta!=metadata: raise AssertionError('Serialization mismatch')
        row={**metadata,'path':str(path.relative_to(ROOT)).replace('\\','/'),'sha256':digest,
             'initial_path':str(initial_path.relative_to(ROOT)).replace('\\','/'),'initial_sha256':initial_digest,
             'initial_fingerprint':initial,'trained_fingerprint':final,'changed_parameters':changed,
             'initial_development':initial_dev,'selected_development':best[3],'development_curve':curve,
             'elapsed_seconds':time.time()-start}
        checkpoints.append(row); print(json.dumps({'trained_seed':seed,'selected_step':best[1],'development':best[3]}),flush=True)
    write_json(ROOT/'training-summary.json',{'schema':'szl.confirmation.training/v1','protocol_sha256':sha(ROOT/'protocol.json'),
        'runtime':{'python':os.sys.version,'torch':torch.__version__,'device':'cpu','threads':torch.get_num_threads()},'checkpoints':checkpoints})

def loaded_models():
    summary=read_json(ROOT/'training-summary.json')
    if summary['protocol_sha256']!=sha(ROOT/'protocol.json'): raise ValueError('Training protocol mismatch')
    result={}
    for row in summary['checkpoints']:
        model,metadata=load(ROOT/row['path'],row['sha256'])
        if metadata['protocol_sha256']!=summary['protocol_sha256'] or metadata['data_receipt_sha256']!=sha(ROOT/'data-receipt.json'):
            raise ValueError('Checkpoint provenance mismatch')
        if fingerprint(model)!=row['trained_fingerprint']: raise ValueError('Checkpoint fingerprint mismatch')
        result[row['seed']]=model
    return result

def _evaluate(p):
    models=loaded_models(); fingerprints={k:fingerprint(v) for k,v in models.items()}
    attempt={'protocol_sha256':sha(ROOT/'protocol.json'),'training_summary_sha256':sha(ROOT/'training-summary.json'),
             'checkpoints':{str(row['seed']):{'path':row['path'],'sha256':row['sha256'],'fingerprint':row['trained_fingerprint']}
                            for row in read_json(ROOT/'training-summary.json')['checkpoints']}}
    attempt_path=ROOT/'evaluation-attempt.json'
    if attempt_path.exists():
        if read_json(attempt_path)!=attempt: raise ValueError('Evaluation attempt/model binding changed')
    else:
        if (ROOT/'evaluation.jsonl').exists() or (ROOT/'evaluation-receipt.json').exists(): raise ValueError('Unbound evaluation artifacts')
        write_json(attempt_path,attempt)
    path=ROOT/'evaluation.jsonl'; existing=[]
    if path.exists():
        raw=path.read_bytes()
        if raw and not raw.endswith(b'\n'): raise ValueError('Incomplete last row; preserve and investigate')
        existing=[json.loads(line) for line in raw.splitlines()]
    expected=[]
    for family in p['families']:
        for index in range(p['episodes_per_family']):
            for policy in p['policies']:
                for model_seed in p['model_seeds'] if policy=='learned' else [None]:
                    expected.append((family,index,policy,model_seed))
    if len(existing)>len(expected): raise ValueError('Too many rows')
    for row,key in zip(existing,expected):
        observed=(row['family'],row['episode_index'],row['policy'],row['model_seed'])
        if observed!=key or row['protocol_sha256']!=sha(ROOT/'protocol.json'): raise ValueError('Invalid committed evaluation prefix')
        content={k:v for k,v in row.items() if k!='row_sha256'}
        digest=hashlib.sha256(json.dumps(content,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        if row['row_sha256']!=digest: raise ValueError('Evaluation row hash mismatch')
    completed=ROOT/'evaluation-receipt.json'
    if completed.exists():
        receipt=read_json(completed)
        if len(existing)!=len(expected) or receipt['evaluation_sha256']!=sha(path) or receipt['attempt_sha256']!=sha(attempt_path):
            raise ValueError('Completed evaluation changed')
        print('Completed evaluation verified; no episodes rerun and no receipt rewritten',flush=True)
        return
    resumed=len(existing); protocol_sha=sha(ROOT/'protocol.json')
    with path.open('ab',buffering=0) as handle:
        for family,index,policy,model_seed in expected[resumed:]:
            result=run_episode(p['test_seed'],index,family,policy,models.get(model_seed),include_history=True)
            result.update({'model_seed':model_seed,'protocol_sha256':protocol_sha})
            result['row_sha256']=hashlib.sha256(json.dumps(result,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
            handle.write((json.dumps(result,sort_keys=True,allow_nan=False)+'\n').encode())
            existing.append(result)
            if len(existing)%500==0: print(f'evaluated {len(existing)}/{len(expected)}',flush=True)
        os.fsync(handle.fileno())
    if {k:fingerprint(v) for k,v in models.items()}!=fingerprints: raise AssertionError('Evaluation mutated weights')
    write_json(ROOT/'evaluation-receipt.json',{'protocol_sha256':protocol_sha,'training_summary_sha256':sha(ROOT/'training-summary.json'),
        'attempt_sha256':sha(attempt_path),
        'evaluation_sha256':sha(path),'rows':len(existing),'resumed_rows':resumed,'new_rows':len(existing)-resumed,
        'weights_unchanged':True,'post_evaluation_fingerprints':fingerprints})

def evaluate(p):
    with evaluation_lock(): _evaluate(p)

def paired(rows,family,candidate,baseline,seed):
    deltas=[]
    for index in range(96):
        selected=[r for r in rows if r['family']==family and r['episode_index']==index]
        a=np.mean([r['net_utility'] for r in selected if r['policy']==candidate])
        b=np.mean([r['net_utility'] for r in selected if r['policy']==baseline])
        deltas.append(a-b)
    values=np.asarray(deltas); rng=np.random.default_rng(seed)
    means=values[rng.integers(len(values),size=(2000,len(values)))].mean(1)
    return {'candidate':candidate,'baseline':baseline,'family':family,'mean_gain':float(values.mean()),
            'ci95':[float(x) for x in np.quantile(means,[.025,.975])],'episode_clusters':len(values),
            'method':'Paired bootstrap over episodes; learned seeds averaged within each episode, not independent replicas'}

def report(p):
    receipt=read_json(ROOT/'evaluation-receipt.json')
    if receipt['evaluation_sha256']!=sha(ROOT/'evaluation.jsonl'): raise ValueError('Evaluation receipt mismatch')
    for key,name in (('protocol_sha256','protocol.json'),('training_summary_sha256','training-summary.json'),('attempt_sha256','evaluation-attempt.json')):
        if receipt[key]!=sha(ROOT/name): raise ValueError('Evaluation provenance mismatch')
    rows=[json.loads(line) for line in (ROOT/'evaluation.jsonl').read_text().splitlines()]
    summaries={}
    for family in p['families']:
        summaries[family]={}
        for policy in p['policies']:
            selected=[r for r in rows if r['family']==family and r['policy']==policy]
            summaries[family][policy]={'rollouts':len(selected),**{m:float(np.mean([r[m] for r in selected])) for m in METRICS}}
    primary=paired(rows,'shared_bias','learned','independent_bias',p['primary']['bootstrap_seed'])
    clean=paired(rows,'clean','learned','independent_bias',p['primary']['bootstrap_seed']+1)
    primary['gain_gate_pass']=primary['mean_gain']>=.03 and primary['ci95'][0]>0
    primary['clean_guard_pass']=clean['mean_gain']>=-.01
    primary['overall_pass']=primary['gain_gate_pass'] and primary['clean_guard_pass']
    analytic=paired(rows,'shared_bias','source_aware','independent_bias',p['primary']['bootstrap_seed']+2)
    references={c:paired(rows,'shared_bias',c,'reference_only',p['primary']['bootstrap_seed']+3) for c in ('learned','source_aware')}
    learned_vs_analytic=paired(rows,'shared_bias','learned','source_aware',p['primary']['bootstrap_seed']+4)
    # Reselect the best non-neural policy inside each whole-episode bootstrap draw.
    control_names=[name for name in p['policies'] if name!='learned']
    table=np.asarray([[np.mean([r['net_utility'] for r in rows if r['family']=='shared_bias' and r['episode_index']==index and r['policy']==policy])
                      for policy in [*control_names,'learned']] for index in range(p['episodes_per_family'])])
    rng=np.random.default_rng(p['primary']['bootstrap_seed']+5)
    bootstrap=table[rng.integers(len(table),size=(2000,len(table)))].mean(1)
    gains=bootstrap[:,-1]-bootstrap[:,:-1].max(1); means=table.mean(0)
    strongest={'candidate':'learned','family':'shared_bias','observed_best_control':control_names[int(means[:-1].argmax())],
               'mean_gain':float(means[-1]-means[:-1].max()),'ci95':[float(x) for x in np.quantile(gains,[.025,.975])],
               'method':'Paired episode bootstrap; strongest control reselected inside each replicate','controls':control_names}
    value={'schema':'szl.confirmation.results/v1','protocol_sha256':sha(ROOT/'protocol.json'),
           'evaluation_sha256':sha(ROOT/'evaluation.jsonl'),'training_summary_sha256':sha(ROOT/'training-summary.json'),
           'rows':len(rows),'primary':primary,'clean_guard':clean,'analytic_comparison':analytic,
           'reference_only_comparisons':references,'summaries':summaries,
           'learned_vs_analytic':learned_vs_analytic,'strongest_control_comparison':strongest,
           'limitations':['Synthetic finite worlds; supplied prior and likelihoods; only acquisition policy is learned',
                         'Six challenge families are public after this run; no further tuning may claim held-out status',
                         'Intervals condition on this protocol and average three trained seeds; no general-domain guarantee',
                         'Primary learned versus independent-bias comparison changes both inference assumptions and acquisition; strongest-control and source-aware comparisons isolate the practical alternatives',
                         'Shared bias assumes source independence for reference; reference-outlier and drift families violate the model']}
    write_json(ROOT/'benchmark-summary.json',value)
    print(json.dumps({'primary':primary,'clean_guard':clean,'analytic':analytic}),flush=True)

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('action',choices=('freeze','data','train','evaluate','report','all')); args=parser.parse_args()
    p=initialize() if args.action in ('freeze','all') else verify_protocol()
    if args.action=='freeze': print(sha(ROOT/'protocol.json')); return
    for action,function in (('data',data),('train',train),('evaluate',evaluate),('report',report)):
        if args.action in (action,'all'): function(p)

if __name__=='__main__': main()
