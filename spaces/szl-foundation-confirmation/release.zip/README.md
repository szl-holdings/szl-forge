# SZL Foundation Confirmation v0.4

A runnable research build for deciding when to buy independent confirmation of potentially correlated evidence. This is a synthetic finite-world experiment with three newly trained small acquisition models, an exact Bayesian predictor, a localhost interface, and retained experiment receipts. It is not an AGI system or evidence of unprecedented scientific capability.

## Run

From this directory, install the pinned dependencies in `requirements.txt` into a Python environment, then use `start.ps1`. The local interface is at `http://127.0.0.1:18766`. It exposes completed benchmark evidence and lets you execute fresh exploratory trials with the actual trained checkpoints. `stop.ps1` stops only the matching local service. The prior v0.3 workbench on port 8765 is separate.

Run `python -B -m unittest discover -v` to exercise the mathematical, acquisition, and service boundaries. Run `python verify_release.py` to verify the packaged files and provenance. See `RESULTS.md` for measured outcomes and limitations, and the `research` directory for the public-source study.

The launcher limits BLAS, OpenMP and MKL worker threads within the service process to reduce memory pressure; it restores the parent shell's settings. If running tests directly on a heavily loaded machine, set `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1` and `MKL_NUM_THREADS=1` in that test process. Existing installed dependencies were used for validation; this release does not claim a clean-install test. Regenerating the already included scientific figure additionally needs `matplotlib==3.11.2`.

Final verification on 25 September 2026 passed 71 tests. The application independently recalculated all 5,184 benchmark records and the confidence intervals. All three checkpoints completed live inference, and four saved trial receipts remained identical after restarting the service. The retained records are under `evidence`. Portable archives exclude mutable `state`, so extracted copies start with an empty interactive trial list; the historical evidence remains available in that folder.

`python package_release.py check` checks packaging readiness without changing model artifacts. The sealed archive can be verified directly with `python verify_release.py --archive ../SZL-foundation-confirmation-v0.4-20260925.zip`. Source, local execution, external publication and deployment are separate: this release is a local research build and does not include a GitHub, Hugging Face or public-domain deployment.

## What changed

The preceding noise-aware model could reduce confident errors without reliably improving task utility. This build introduces a different action: a more expensive observation from a separate reference channel. Its hypothesis is that evidence sharing a persistent source bias needs independent confirmation, while clean evidence should not incur unnecessary confirmation cost.

Each episode contains four target groups with sixteen possible labels. A cheap source adds one shared hidden offset to all its reports; the reference source has separate fresh noise. The inference engine explicitly represents the joint distribution of source bias and target labels. It does not discover new physical laws. Its prior combines 76 supplied structured worlds with a product component supporting every four-label combination.

Every policy begins with the same four inherited cheap reports, one per group. These represent evidence already acquired and have zero **additional** cost. The policy then has four resource units: a cheap report costs one unit and 0.025 utility; a reference report costs two units and 0.05 utility. Repeated paid readings are allowed. Reusing the same observation ID is rejected. A repeated reading can reduce fresh noise but does not independently eliminate shared bias.

The neural policy is a 26,792-parameter multilayer perceptron. It receives public priors, target weights, prices, remaining resources, and raw observed history. It does not receive the true labels, sensor family, bias, random seed, exact posterior or exact teacher action values as input. It learns to approximate the analytic controller's one-step acquisition utilities. The Bayesian predictor remains programmed and shared with the source-aware baselines.

## Evaluation discipline

`protocol.json` is frozen before data generation, training and challenge evaluation. It binds the exact core, policy and runner sources. The train, development and challenge seeds are disjoint. Three models train from fresh initial weights; development decision regret chooses a checkpoint. The challenge outcomes do not choose models or thresholds.

The seven policy names cover no additional confirmation, independent-bias inference, source-aware inference, paid cheap-only acquisition, paid reference-only acquisition, random mixed acquisition and learned acquisition. Restricted-channel controls still receive the same four inherited cheap reports. The independent-bias ablation preserves the per-reading bias distribution but redraws that bias independently, allowing a comparison of dependence assumptions.

Six challenge families test clean sensors, shared cheap-source bias, independent cheap outliers, reference outliers, action-dependent bias drift and compositional changes. Drift starts after the first paid cheap reading, so it is deliberately history dependent. The precomputed noise tape pairs each source/group/visit across policies; that does not make drift outcomes independent of the preceding actions.

Utility is target-weighted accuracy minus paid observation cost. Confident error, coverage, Brier score, log loss and channel usage are reported separately. The primary confidence interval resamples whole episodes after averaging the three learned seeds within each episode; it does not count those seeds as independent worlds. An inexpensive control can beat a more accurate policy, and every result remains visible.

The source prior assumes 80% zero bias, while challenge families are stratified and training draws equal numbers in expectation from clean and shared-bias families. Consequently model probabilities are not claimed to be calibrated to the overall evaluation distribution. The reference-outlier and drift conditions deliberately violate likelihood assumptions. The analytic controller is one-step greedy rather than globally optimal sequential planning.

## Research and provenance

The research map covers public papers from Qwen/Alibaba, DeepSeek-AI, Ukrainian Catholic University, West Ukrainian National University and Oxford, together with public CIA, NSA, IARPA and DARPA material. These are selective relevant sources, not a ranking of institutions. The build independently implements a small experiment inspired by the questions they raise; it does not reproduce their reported benchmarks or imply endorsement.

No upstream model weights or code were imported. The official repositories were inspected at exact revisions, with license observations retained. The mathematical core has a separate internal review against dense enumeration of all 1,048,576 latent states. This review is by another collaborating agent, not an independent institution.

`data-receipt.json`, `training-summary.json`, `evaluation-receipt.json`, `benchmark-summary.json` and the release manifest bind the principal artifacts with SHA-256. Hashes detect drift relative to retained receipts; they are not signatures or an external trust anchor. Evaluation can resume from a validated complete prefix, refusing incomplete or mismatched rows. Later interactive trials are exploratory and do not amend the frozen benchmark.

Reproducing training is a separate experiment: copy the source to a new directory and remove generated artifacts there, preserving this release. The build refuses to overwrite existing datasets or a completed training summary. No model training, evaluation or public deployment is triggered merely by opening the interface.
