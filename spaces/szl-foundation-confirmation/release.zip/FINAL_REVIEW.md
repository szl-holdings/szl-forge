# Final release review — Foundation Confirmation v0.4

Reviewed 25 September 2026 by a collaborating agent separate from the release implementer. This is internal technical review, not external replication, peer review, or an independent authorship signature.

**Disposition: release review passes for an honestly reported local synthetic-research package. The main task's retained sequential check reports `READY_TO_SEAL`; this review precedes sealing and does not itself certify an archive.** No blocking source or interpretation defect was identified in the inspected scope. A negative scientific outcome can be packaged honestly, and the registered overall criterion remains failed.

## Scope and evidence

Read `verify_release.py`, `package_release.py`, `test_release.py`, `RESULTS.md`, `README.md`, the existing `INDEPENDENT_REVIEW.md/json`, frozen protocol, data/training/evaluation receipts, and the retained benchmark summary. Inspected the report's paired-bootstrap and decision code without running the report, training, or evaluation. Reviewed the previously retained browser and previous-release investigation receipts as historical evidence, not fresh runtime observations.

Fresh SHA-256 readbacks of `core.py`, `policy.py` and `experiment.py` match both the frozen protocol and existing implementation review. The fresh protocol, training-summary and evaluation-attempt digests match the respective downstream receipt bindings. This limited text/hash inspection is distinct from completing the full 5,184-row verifier.

The existing implementation review remains applicable to those unchanged source files. Its successful dense mathematical comparison and tests were witnessed by that earlier reviewer; they were not rerun in this final review. Application changes, full-suite execution, browser behavior and service persistence are owned by the main release task and require their own evidence. Before finalizing this review, I read its fresh `evidence/package-readiness.json` and `evidence/full-tests.txt`: the former reports all 5,184 evaluation rows and 160,752 tensor values checked; the latter records 71 passing tests in 8.317 seconds. These are retained main-task execution results, not commands executed by this reviewer.

I also inspected the new application-level `recompute_report` function and `test_benchmark_admission.py`. The function calculates aggregates, paired intervals, strongest-control selection and gate booleans separately from the frozen experiment report. The three passing retained-data tests cover successful recomputation, altered gate/aggregate/interval rejection, and evidence/source changes after cache population. This closes the application report-admission gap without changing the frozen experiment, models or evaluation. The application launcher now scopes OpenBLAS/OMP/MKL thread limits to its spawned process and restores the calling process settings in `finally`; it launches the helper with a hidden window.

## Scientific outcome remains explicit

The retained summary and human-readable results agree:

- Three fresh 26,792-parameter acquisition models were trained; selected checkpoint steps are 400, 400 and 200 for seeds 17, 23 and 41. Each retained training receipt reports all 26,792 selected parameters changed from initialization.
- The retained evaluation has 5,184 rollouts over 576 distinct synthetic worlds, with 96 episode clusters in each of six families. The evaluation receipt reports one uninterrupted attempt, zero resumed rows and unchanged model fingerprints.
- Learned shared-bias utility minus independent-bias utility is `0.8793777426281914`, with retained paired bootstrap interval `[0.8254157446938117, 0.9214102401722001]`. The gain gate passes.
- The clean-family difference is `-0.01967543252581175`, below the permitted `-0.01`; the clean guard fails and `overall_pass=false`.
- The strongest observed shared-bias control is paid reference only. The learned difference is `-0.009557850457884154`, with interval `[-0.035227637187814485, 0.010461524532693566]`. The source-aware analytic comparison is also inconclusive. Neither establishes learned superiority.

The report explains that the primary comparison changes both inference assumptions and acquisition, preserves adverse secondary conditions, and describes only learned acquisition backed by a programmed Bayesian predictor. It does not claim AGI, an independently learned world model, general factual reliability, foundation-language-model capability, external deployment, or global novelty. Results from later exploratory interface trials cannot amend this frozen benchmark.

## Packaging assessment

The verifier uses the Python standard library and checks explicit manifest file sets, file lengths and SHA-256, canonical relative paths, case collisions, duplicate ZIP members, CRC, checkpoint layout and finite values, source/data/checkpoint/evaluation bindings, evaluation row identity/order/digests, acquisition accounting, aggregate means and the observed strongest-control comparison. It does not import the packaged model implementation or run inference, training or evaluation.

The packager refuses an existing manifest, archive or receipt, requires the archive outside the release directory, verifies the directory before and after packaging, and verifies the archive itself before emitting its completion receipt. Its state/cache/log/lock exclusions address the class of volatile-file problem documented for the earlier v0.3 extracted directory. That historical strict verification failure is preserved in its own investigation rather than described as repaired.

The following boundaries remain material:

- Hashes prove consistency with retained bytes, not independent authorship, chronological preregistration, or protection against a party replacing the evidence and all associated hashes together.
- The standalone archive verifier does not independently recompute bootstrap intervals or registered gate booleans. Their derivation was inspected in the frozen report code, and the displayed values and decision were compared with retained summaries. The separate application admission calculation does recompute them, and the main task's retained tests show this path and tamper rejection passing. This reviewer did not rerun bootstrap analysis.
- `READY_TO_SEAL` describes the package's evidence and file checks; runtime and behavioral test success are separate gates. This review does not substitute for the main task's final test and service receipts.
- The pinned dependency file explicitly records an observed CPU environment and does not claim a fresh, isolated dependency installation was validated.

## Read-only execution attempt

Command: `C:/Users/steph/AppData/Local/Programs/Python/Python311/python.exe -B package_release.py check`.

The first attempt exited 1 with `MemoryError` in `verify_release.py:102`, while slicing a checkpoint payload in `inspect_checkpoint`. A concurrent read-only PowerShell process also terminated with `Out of memory`. This did not establish an evidence mismatch and did not complete package verification. No manifest, archive, training, evaluation or other release file was written by this review. The main release task requested that additional checks wait for its sequential test execution to finish.

The review's machine-readable companion preserves this unsuccessful attempt. The main release task subsequently produced a successful sequential `READY_TO_SEAL` result in `evidence/package-readiness.json`, which I read and hashed. It binds protocol `dd0c4694...`, training summary `c4e40e50...` and evaluation `6a35a347...`, with three selected and three initial checkpoints. The main task reports that limiting numerical-library worker counts resolved its resource failure; this reviewer has not independently established the host-wide causal diagnosis.

The successful readiness check described 59 files at its execution time. Final review and runtime receipts may be added afterward, so sealing must build and verify the final file set again. Actual directory/archive sealing verification and current runtime/restart observations belong to the main task and must be reported separately before claiming a verified, running package.

## Reviewed identity

- Protocol: `dd0c469401a71c73d196320260d27f58d2e9cf7a8be7bd78ece3cad1a6cca10e`.
- Core: `573740e2f3e138b82508b49e29ad55c11e2a6e29c07fd44fe49f973628632c69`.
- Selector: `02705491ed34ca23ef2e900768ad33dc96903c16729a9981ad72475bf4379919`.
- Experiment controller: `a763286c6e29dd041ff8e09a3c49f6376e3c08383d5be38788d4b81f65854a11`.
- Release verifier: `b7b5d7775fadc6933144c16e17db2ee64e63c18b43d412a593eba927f53672f9`.
- Packager: `52661f7049b446033926acba54a4b85a51cb3d858d693d54f4b0258a99910739`.
- Application source inspected for report admission: `ffa50276f1956f78dc9738a36f1855e95a71c1621c52e6b1c8a6a54ddcbc55fb`.
- Benchmark-admission tests: `b750ff9518dc52387e702a1ebdcc90c29ce6038e8455c2af052c7d7c8b8d7585`.
- Retained readiness evidence: `429efa8696ca6e204940b1f47fcefdf601123a84c2a023d6197a7f9b936a42d0`.
- Retained complete test log: `ba3185b2045157311e7a4f0538c07eabee93b19aa8a7bac50422d2e7074b8116`.

This review changes only `FINAL_REVIEW.md` and `FINAL_REVIEW.json` and must be included before the final package is sealed.
