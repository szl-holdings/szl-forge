param([ValidateRange(1, 65535)][int]$Port = 18766)
$ErrorActionPreference = 'Stop'
$labRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$serverScript = Join-Path $labRoot 'server.py'
$statePath = Join-Path $labRoot 'state'
[IO.Directory]::CreateDirectory($statePath) | Out-Null
$receiptPath = Join-Path $statePath 'service.json'
if (Test-Path -LiteralPath $receiptPath) {
    $priorService = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
    $priorProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$([int]$priorService.pid)" -ErrorAction SilentlyContinue
    if ($priorProcess -and $priorProcess.CommandLine -match [regex]::Escape($serverScript)) {
        Write-Output "This lab already has a running process (PID $($priorService.pid)). Use stop.ps1 before restarting."
        exit 0
    }
}
$preferredPython = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe'
if (Test-Path -LiteralPath $preferredPython) { $pythonPath = $preferredPython }
else { $pythonPath = (Get-Command python -ErrorAction Stop).Source }
$arguments = @('-X', 'utf8', '-B', ('"' + $serverScript + '"'), '--port', [string]$Port)
$threadSettings = @{}
try {
    foreach ($setting in @('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS')) {
        $threadSettings[$setting] = [Environment]::GetEnvironmentVariable($setting, 'Process')
        [Environment]::SetEnvironmentVariable($setting, '1', 'Process')
    }
    $serviceProcess = Start-Process -FilePath $pythonPath -ArgumentList $arguments -WorkingDirectory $labRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $statePath 'service.stdout.log') -RedirectStandardError (Join-Path $statePath 'service.stderr.log')
} finally {
    foreach ($setting in $threadSettings.Keys) {
        [Environment]::SetEnvironmentVariable($setting, $threadSettings[$setting], 'Process')
    }
}
$processInfo = Get-CimInstance Win32_Process -Filter "ProcessId=$($serviceProcess.Id)" -ErrorAction Stop
@{pid=$serviceProcess.Id; server_script=$serverScript; executable=$processInfo.ExecutablePath; process_created=$processInfo.CreationDate.ToUniversalTime().ToString('o'); port=$Port; launched_utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding utf8
$healthUrl = "http://127.0.0.1:$Port/healthz"
for ($attempt = 0; $attempt -lt 30; $attempt++) {
    $serviceProcess.Refresh()
    if ($serviceProcess.HasExited) { throw "The service exited. Read state/service.stderr.log for the retained error." }
    try {
        $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2
        if ($health.service -eq 'szl-foundation-confirmation' -and $health.process_id -eq $serviceProcess.Id) {
            Write-Output "Source-aware confirmation: http://127.0.0.1:$Port"
            Write-Output "PID $($serviceProcess.Id). Build readiness is shown in the interface; /healthz only proves the server is running."
            exit 0
        }
    } catch { }
    Start-Sleep -Milliseconds 200
}
throw "The process was started but health was not witnessed. Inspect state/service.stdout.log and state/service.stderr.log."
